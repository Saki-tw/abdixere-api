//! SakiMCPDeus — Unrestricted MCP Server for LLM Agent Tool Execution
//!
//! Saki Studio · S700 MoreFine · x86_64-pc-windows-gnullvm

mod server;

use server::DeusMcpServer;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    use rmcp::serve_server;

    eprintln!("[INFO] SakiMCPDeus v0.1.0 Starting (rmcp SDK, stdio)");
    eprintln!("[INFO] Tools: run_command, read_file, write_file, list_files, search_files, search_filename");
    eprintln!("[INFO] Mode: UNRESTRICTED — all paths and commands allowed");

    let handler = DeusMcpServer::new();

    let stdin = tokio::io::stdin();
    let stdout = tokio::io::stdout();

    let running = serve_server(handler, (stdin, stdout)).await?;
    running.waiting().await?;

    eprintln!("[INFO] SakiMCPDeus Exited");
    Ok(())
}
