//! SakiMCPDeus — 精簡版 MCP Server for LLM Agent Tool Execution
//!
//! 僅保留：run_command, read_file, write_file, list_files, search_files, search_filename
//! 預設權限全開，無路徑限制，無 Session Guard
//! instructions 欄位注入 Saki Studio 機構規範
//! 設計供 Antigravity / Gemini-CLI / Claude Code 等 Agent 使用

use rmcp::{
    ServerHandler,
    handler::server::tool::ToolRouter,
    handler::server::wrapper::Parameters,
    model::*,
    tool, tool_router, tool_handler,
    ErrorData as McpError,
};
use schemars::JsonSchema;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

// ===== 參數結構 =====

#[derive(Debug, Deserialize, Serialize, JsonSchema)]
pub struct FilePathArgs {
    /// 檔案完整路徑
    pub file_path: String,
}

#[derive(Debug, Deserialize, Serialize, JsonSchema)]
pub struct WriteFileArgs {
    /// 檔案完整路徑
    pub file_path: String,
    /// 檔案內容
    pub content: String,
}

#[derive(Debug, Deserialize, Serialize, JsonSchema)]
pub struct ListFilesArgs {
    /// 目錄路徑
    pub directory_path: String,
    /// 最大深度（預設 3）
    #[serde(default)]
    pub max_depth: Option<u32>,
}

#[derive(Debug, Deserialize, Serialize, JsonSchema)]
pub struct SearchFilesArgs {
    /// ripgrep 搜尋模式
    pub query: String,
    /// 搜尋路徑（預設當前目錄）
    #[serde(default)]
    pub search_path: Option<String>,
}

#[derive(Debug, Deserialize, Serialize, JsonSchema)]
pub struct SearchFilenameArgs {
    /// fd 搜尋模式
    pub pattern: String,
    /// 搜尋路徑（預設當前目錄）
    #[serde(default)]
    pub search_path: Option<String>,
}

#[derive(Debug, Deserialize, Serialize, JsonSchema)]
pub struct RunCommandArgs {
    /// 要執行的命令
    pub command: String,
    /// 工作目錄（預設 HOME）
    #[serde(default)]
    pub cwd: Option<String>,
    /// 逾時秒數（預設 60，最大 300）
    #[serde(default)]
    pub timeout_secs: Option<u64>,
}

// ===== Saki Studio Instructions Inject =====

/// MCP ServerInfo instructions 欄位：注入至所有連接的 Agent 系統提示詞
const SAKI_INSTRUCTIONS: &str = r#"你正在透過 SakiMCPDeus MCP Server 與 Saki Studio 機構的 S700 算力機互動。

## 機構基本資訊
- 機構：Saki Studio — 「為言說而生，在資源匱乏的邊緣，尋找計算與意義的極大值。」
- 機構目錄：E:\Saki_Studio\（Windows 側）
- WSL：Ubuntu-24.04（/mnt/e/Saki_Studio/）
- 時區：UTC+8 Asia/Taipei
- 語言：台灣地區繁體中文優先

## 工具使用規範
1. run_command：無任何限制。固定使用 PowerShell。WSL 命令用 wsl -- bash -c 包裝
2. read_file / write_file：無路徑限制，自動建立父目錄
3. list_files / search_filename：使用 fd，需要已安裝
4. search_files：使用 rg (ripgrep)，需要已安裝

## 檔案命名標準
- 格式：YYYYMMDDhhmm_{專案簡稱}_{簡短描述}.{ext}
- 時間戳：UTC+8
- 分隔符：底線 _，禁止空格

## 非同步歸檔架構
- ImplementationLog/：規劃完成後
- TaskLog/：任務建立時
- Scientia/：研究/分析完成後
- WalkthroughLog/：階段完成歸檔

## 環境工具鏈
- Windows：cmd, PowerShell, winget, scoop, fd, rg, 7z, gsudo, vi, ffmpeg
- WSL：Ubuntu-24.04, brew, rustup (beta-x86_64-pc-windows-gnullvm)
- 外部服務：Cloudflare (Pages/Workers/Tunnel), GitHub
"#;

// ===== Server =====

#[derive(Clone)]
pub struct DeusMcpServer {
    tool_router: ToolRouter<Self>,
}

#[tool_router]
impl DeusMcpServer {
    pub fn new() -> Self {
        Self {
            tool_router: Self::tool_router(),
        }
    }

    #[tool(description = "Read file contents. No path restrictions. Returns text for text files, type info for binary files.")]
    async fn read_file(&self, Parameters(args): Parameters<FilePathArgs>) -> Result<CallToolResult, McpError> {
        match tokio::fs::read(&args.file_path).await {
            Ok(bytes) => {
                let check_len = bytes.len().min(512);
                if bytes[..check_len].contains(&0u8) {
                    let ext = std::path::Path::new(&args.file_path)
                        .extension().and_then(|e| e.to_str()).unwrap_or("?");
                    Ok(CallToolResult::success(vec![Content::text(
                        format!("[Binary file: {:.1}KB, ext: .{}]", bytes.len() as f64 / 1024.0, ext)
                    )]))
                } else {
                    match String::from_utf8(bytes) {
                        Ok(c) => Ok(CallToolResult::success(vec![Content::text(c)])),
                        Err(e) => {
                            let lossy = String::from_utf8_lossy(e.as_bytes());
                            Ok(CallToolResult::success(vec![Content::text(
                                format!("[Non-UTF8, lossy conversion]\n{}", lossy)
                            )]))
                        }
                    }
                }
            }
            Err(e) => Ok(CallToolResult::error(vec![Content::text(format!("Error: {e}"))])),
        }
    }

    #[tool(description = "Write content to file. Creates parent directories automatically. No path restrictions.")]
    async fn write_file(&self, Parameters(args): Parameters<WriteFileArgs>) -> Result<CallToolResult, McpError> {
        if let Some(p) = std::path::Path::new(&args.file_path).parent() {
            let _ = tokio::fs::create_dir_all(p).await;
        }
        match tokio::fs::write(&args.file_path, &args.content).await {
            Ok(_) => Ok(CallToolResult::success(vec![Content::text(
                format!("Wrote {} bytes to {}", args.content.len(), args.file_path)
            )])),
            Err(e) => Ok(CallToolResult::error(vec![Content::text(format!("Error: {e}"))])),
        }
    }

    #[tool(description = "List files in directory using fd (max_depth default 3). No path restrictions.")]
    async fn list_files(&self, Parameters(args): Parameters<ListFilesArgs>) -> Result<CallToolResult, McpError> {
        let depth = args.max_depth.unwrap_or(3).to_string();
        let out = tokio::process::Command::new("fd")
            .args(["--type", "f", "--max-depth", &depth, ".", &args.directory_path])
            .output().await;
        match out {
            Ok(o) => {
                let s = String::from_utf8_lossy(&o.stdout);
                let files: Vec<_> = s.lines().collect();
                Ok(CallToolResult::success(vec![Content::text(
                    serde_json::json!({"files": files, "count": files.len()}).to_string()
                )]))
            }
            Err(e) => Ok(CallToolResult::error(vec![Content::text(format!("Error: {e}"))])),
        }
    }

    #[tool(description = "Search file contents with ripgrep (rg --json). No path restrictions.")]
    async fn search_files(&self, Parameters(args): Parameters<SearchFilesArgs>) -> Result<CallToolResult, McpError> {
        let p = args.search_path.unwrap_or_else(|| ".".into());
        let out = tokio::process::Command::new("rg")
            .args(["--json", "--max-count", "50", &args.query, &p])
            .output().await;
        match out {
            Ok(o) => {
                let s = String::from_utf8_lossy(&o.stdout);
                let mut matches: Vec<serde_json::Value> = vec![];
                for l in s.lines() {
                    if let Ok(j) = serde_json::from_str::<serde_json::Value>(l) {
                        if j.get("type").and_then(|t| t.as_str()) == Some("match") {
                            if let Some(d) = j.get("data") {
                                matches.push(serde_json::json!({
                                    "file": d.get("path").and_then(|x| x.get("text")),
                                    "line": d.get("line_number"),
                                    "content": d.get("lines").and_then(|x| x.get("text"))
                                }));
                            }
                        }
                    }
                }
                Ok(CallToolResult::success(vec![Content::text(
                    serde_json::json!({"matches": matches, "count": matches.len()}).to_string()
                )]))
            }
            Err(e) => Ok(CallToolResult::error(vec![Content::text(format!("Error: {e}"))])),
        }
    }

    #[tool(description = "Search filenames with fd. No path restrictions.")]
    async fn search_filename(&self, Parameters(args): Parameters<SearchFilenameArgs>) -> Result<CallToolResult, McpError> {
        let p = args.search_path.unwrap_or_else(|| ".".into());
        let out = tokio::process::Command::new("fd")
            .args(["--max-depth", "5", &args.pattern, &p])
            .output().await;
        match out {
            Ok(o) => {
                let s = String::from_utf8_lossy(&o.stdout);
                let files: Vec<_> = s.lines().collect();
                Ok(CallToolResult::success(vec![Content::text(
                    serde_json::json!({"files": files, "count": files.len()}).to_string()
                )]))
            }
            Err(e) => Ok(CallToolResult::error(vec![Content::text(format!("Error: {e}"))])),
        }
    }

    #[tool(description = "Run a command via PowerShell on Win64. No restrictions. Timeout default 60s, max 300s. For WSL: use 'wsl -- bash -c \"...\"' as the command.")]
    async fn run_command(&self, Parameters(args): Parameters<RunCommandArgs>) -> Result<CallToolResult, McpError> {
        let cmd = args.command.trim();
        let cwd = args.cwd.map(PathBuf::from)
            .unwrap_or_else(|| dirs::home_dir().unwrap_or_else(|| PathBuf::from(".")));

        let timeout = std::time::Duration::from_secs(
            args.timeout_secs.unwrap_or(60).clamp(1, 300)
        );

        // Win64 固定 PowerShell — 這是 Deus 版，不是跨平台原版
        let shell = "powershell";
        let shell_arg = "-NoProfile";

        let result = tokio::time::timeout(
            timeout,
            tokio::process::Command::new(shell)
                .arg(shell_arg)
                .arg("-Command")
                .arg(cmd)
                .current_dir(&cwd)
                .env("PAGER", "cat")
                .env("NO_COLOR", "1")
                .output()
        ).await;

        match result {
            Ok(Ok(output)) => {
                let stdout = String::from_utf8_lossy(&output.stdout);
                let stderr = String::from_utf8_lossy(&output.stderr);
                let exit_code = output.status.code().unwrap_or(-1);

                let max_len = 100_000;
                let stdout_out = if stdout.len() > max_len {
                    format!("{}...(truncated, {} bytes total)", &stdout[..max_len], stdout.len())
                } else {
                    stdout.to_string()
                };

                let mut parts = vec![format!("exit: {}", exit_code)];
                if !stdout_out.is_empty() { parts.push(format!("stdout:\n{}", stdout_out)); }
                if !stderr.is_empty() {
                    let se = if stderr.len() > 10000 { format!("{}...(truncated)", &stderr[..10000]) } else { stderr.to_string() };
                    parts.push(format!("stderr:\n{}", se));
                }
                Ok(CallToolResult::success(vec![Content::text(parts.join("\n"))]))
            }
            Ok(Err(e)) => Ok(CallToolResult::error(vec![Content::text(format!("Exec error: {e}"))])),
            Err(_) => Ok(CallToolResult::error(vec![Content::text(
                format!("Timeout after {}s", timeout.as_secs())
            )])),
        }
    }
}

// ===== ServerHandler =====

#[tool_handler]
impl ServerHandler for DeusMcpServer {
    fn get_info(&self) -> ServerInfo {
        ServerInfo {
            protocol_version: ProtocolVersion::LATEST,
            capabilities: ServerCapabilities::builder()
                .enable_tools()
                .build(),
            server_info: Implementation {
                name: "SakiMCPDeus".into(),
                title: Some("SakiMCPDeus — Saki Studio Unrestricted Agent Toolchain".into()),
                version: "0.1.0".into(),
                icons: None,
                website_url: Some("https://saki-studio.com.tw".into()),
            },
            instructions: Some(SAKI_INSTRUCTIONS.into()),
        }
    }
}
