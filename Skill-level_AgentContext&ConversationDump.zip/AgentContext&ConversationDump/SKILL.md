---
name: AgentContext&ConversationDump
description: |
  Agent 對話備份、上下文恢復、Session 接續、對話匯出與歷史知識提取。統一涵蓋 Antigravity 與 Gemini CLI 兩種環境。觸發條件：
  (1) CHECKPOINT 截斷或重啟後需恢復先前任務進度
  (2) 歸檔對話、生成創世提示詞或交接新 Session（協議九 / Session Handoff）
  (3) 查閱 ChatMelius 歷史對話中的技術決策或實作記錄
  (4) 批次歸檔多個 Session（Brain 目錄清理）
  (5) context window 過載，需開新 Session 接續未完成工作
  (6) 分析 Antigravity 內部結構（~/.gemini/、brain/、conversations/、knowledge/）
  (7) Gemini CLI 環境下執行對話備份或解析 logs.json
  (8) 匯出 Antigravity 對話紀錄（ConnectRPC / abdixere-api / PB 離線解密）
  (9) PB 加密機制研究（AES-256-GCM、硬編碼密鑰）
  (10) 跨工具對話合併（Antigravity + Gemini CLI 統一歸檔）
  (11) 動態資料源整合（LS 伺服器監聽、Deus logger、console-logger）
  所有備份產出歸檔至 SakiAgentHistory/ChatMelius/。
  最後更新：2026-03-30（v1.21.6 品牌重命名適配）。
---

# Agent 上下文備份、恢復與對話匯出

## 環境判斷

首先判斷當前環境：

| 環境 | 判斷方式 | 適用章節 |
|------|----------|----------|
| **Antigravity (macOS)** | `~/.gemini/antigravity/` 存在 + Brain 目錄可讀 | §一～§六全部 |
| **Antigravity (Win64)** | `C:\Users\daubl\.gemini\antigravity\` 存在 | §一～§六（路徑映射至 Win64 常量） |
| **Gemini CLI** | 僅 `~/.gemini/history/` 存在、無 Brain 獨立存儲 | §一（有限）、§三（Gemini CLI 模式）、§七 |
| **混合** | 同一任務跨兩種環境 | 以 Antigravity 為主 + §七合併 |

## 路徑常量

### macOS (M1 Mac Mini)

| 名稱 | 路徑 |
|------|------|
| ChatMelius | `/Users/hc1034/Saki_Studio/Claude/SakiAgentHistory/ChatMelius/` |
| Brain | `~/.gemini/antigravity/brain/{conversation-id}/` |
| Conversations | `~/.gemini/antigravity/conversations/*.pb` |
| Knowledge | `~/.gemini/antigravity/knowledge/` |
| Scientia | `/Users/hc1034/Saki_Studio/Claude/SakiAgentHistory/Scientia/` |
| 索引 | `ChatMelius/INDEX.md` |
| 時間軸 | `ChatMelius/TIMELINE.md` |
| abdixere-api | `/Users/hc1034/Saki_Studio/Claude/SakiAgentHistory/abdixere-api/target/release/abdixere-api` |

### S700 Win64 (Windows/Antigravity)

| 名稱 | 路徑 |
|------|------|
| ChatMelius | `E:\Saki_Studio\SakiAgentHistory\ChatMelius\` |
| Brain | `C:\Users\daubl\.gemini\antigravity\brain\{conversation-id}\` |
| Conversations | `C:\Users\daubl\.gemini\antigravity\conversations\*.pb` |
| Knowledge | `C:\Users\daubl\.gemini\antigravity\knowledge\` |
| Scientia | `E:\Saki_Studio\SakiAgentHistory\Scientia\` |
| 索引 | `ChatMelius\INDEX.md` |
| abdixere-api | 需在 WSL 中編譯：`/mnt/e/Saki_Studio/SakiAgentHistory/abdixere-api/` |

> ⚠️ S700 路徑映射：`/Users/hc1034/Saki_Studio/Claude/` → `E:\Saki_Studio\`

> ⚠️ **abdixere-api 首次使用**：若 binary 不存在，需先編譯：`cd abdixere-api && cargo clean && cargo build --release`

## 研究資源

- **逆向方法論**：[references/研究方法論.md](references/研究方法論.md)
- **Antigravity 內部結構**：[references/antigravity_internals.md](references/antigravity_internals.md)
- **恢復路徑速查**：[references/recovery_paths.md](references/recovery_paths.md)
- **批次歸檔流程**：[references/batch_archive.md](references/batch_archive.md)
- **提取方法詳細命令**：[references/extraction_methods.md](references/extraction_methods.md)

---

## 一、分級恢復（CHECKPOINT 觸發時）

根據 `ls -ltT ~/.gemini/antigravity/brain/{conversation-id}/` 最後修改時間與當前時間差：

| 時間差 | 強度 | 操作 |
|--------|------|------|
| < 30 秒 | 無需恢復 | 直接繼續 |
| 30 秒 ~ 5 分鐘 | 輕度 | 讀 `brain/task.md` |
| 5 分鐘 ~ 1 小時 | 標準 | 讀 `task.md` + `walkthrough.md`，比對 artifact 差異 |
| > 1 小時 | 完整 | 讀全部 Brain artifacts + Scientia/ + `git log -5`，主動告知用戶 |

> **CHECKPOINT 高頻時**：改用 `mcp_SakiMCP_read_file`（allow_system_paths=true），不依賴終端。

**Gemini CLI 環境**：無 Brain artifacts 獨立存儲，恢復順序改為：
```
專案自有的 task.md/walkthrough.md → Scientia/ → ChatMelius 歷史 → GEMINI.md
```

---

## 二、快速恢復

僅需恢復工作進度時使用。優先順序：

```
Brain task.md → Scientia → git log → ARCHITECTURE.md → ChatMelius（最終手段）
```

1. 定位會話 — 查 `ChatMelius/INDEX.md`，必要時用 `TIMELINE.md` 縮小範圍
2. 讀取 artifacts — 依序讀 `task.md` → `walkthrough.md` → `implementation_plan.md`
3. 組合摘要回到需求專案繼續工作

---

## 三、完整備份歸檔（Session Handoff / 協議九）

> ⚠️ **Conversation Dump 為強制步驟**。未執行 conversation dump 的歸檔視為不完整，不得跳過。

跨 Session 交接或長期歸檔時使用。所有產出直接寫入 ChatMelius。

### 強制產出清單（Antigravity 模式）

以下 6 項為**必須全部產出**的檔案，缺一不可：

| # | 檔案 | 來源 | 強制 |
|---|------|------|:----:|
| 1 | `conversation_dump.md` | **abdixere-api dump / ConnectRPC（見§四）** | **必須** |
| 2 | `trajectory_steps.json` | **abdixere-api dump 自動產出** | **必須** |
| 3 | `task.md` | Brain artifact 複製 | **必須** |
| 4 | `implementation_plan.md` | Brain artifact 複製 | **必須** |
| 5 | `walkthrough.md` | Brain artifact 複製 | **必須** |
| 6 | `handoff_prompt.md` | Agent 生成（交接提示詞） | **必須** |

### 強制產出清單（Gemini CLI 模式）

| # | 檔案 | 來源 | 強制 |
|---|------|------|:----:|
| 1 | `session_summary.md` | Agent 生成摘要 | **必須** |
| 2 | `task.md` | 專案目錄複製（若有） | **必須** |
| 3 | `handoff_prompt.md` | Agent 生成（交接提示詞） | **必須** |

### 執行步驟（嚴格依序，不得跳步）

**步驟 1 — 建立 ChatMelius 資料夾**：

```bash
ls ChatMelius/ | sort -t_ -k1 -n | tail -5   # 決定序號
TARGET="ChatMelius/{序號}_{英文標題}"
mkdir -p "$TARGET"
```

**步驟 2 — Conversation Dump（強制）**：

> 🔴 **此步驟為強制執行，不得跳過、延後或以「稍後補做」替代。**

執行 abdixere-api dump，產出 `conversation_dump.md` + `trajectory_steps.json`：

```bash
/Users/hc1034/Saki_Studio/Claude/SakiAgentHistory/abdixere-api/target/release/abdixere-api dump <cascade-id> -o "$TARGET"
```

驗證產出：

```bash
ls -lh "$TARGET"/conversation_dump.md "$TARGET"/trajectory_steps.json
# 兩個檔案均必須存在且大小 > 0
```

若 abdixere-api 不可用，依§四的分派邏輯 fallback。**無論使用何種方法，conversation_dump.md 必須存在才能繼續下一步。**

**步驟 3 — 複製 Brain Artifacts**：

```bash
scripts/backup_brain.sh <uuid> <序號> <標題>
# 或手動複製 task.md + walkthrough.md + implementation_plan.md
```

**步驟 4 — Agent 生成 handoff_prompt.md**：

包含：完成事項摘要、未完成事項、錯誤統計（若有）、修改檔案清單、下一 Session 起始建議。

**步驟 5 — 更新 INDEX.md**：

追加新條目至 `ChatMelius/INDEX.md`。

**步驟 6 — 歸檔驗證**：

> 🔴 **歸檔完成前必須驗證以下檢查清單，全部通過才能通知用戶。**

```bash
# 驗證所有必須檔案存在
ls "$TARGET"/{conversation_dump.md,trajectory_steps.json,task.md,walkthrough.md,implementation_plan.md,handoff_prompt.md}
# 驗證 conversation_dump.md 非空
[ -s "$TARGET/conversation_dump.md" ] && echo "✅ dump OK" || echo "❌ dump EMPTY"
# 驗證 INDEX.md 已更新
tail -1 ChatMelius/INDEX.md
```

---

## 四、對話全文提取

根據環境選擇方案。詳細命令見 [extraction_methods.md](references/extraction_methods.md)。

| 優先 | 方案 | 說明 |
|:---:|------|------|
| 0 | **abdixere-api dump** | 自動偵測 + fallback（ConnectRPC→Brain），產出 md + json |
| 1 | **GetCascadeTrajectorySteps** | 最完整：662 步驟 / 4.2MB JSON |
| 2 | **PB 離線解密** | Key=`safeCodeiumworldKeYsecretBalloon`（AES-256-GCM） |
| 3 | **Brain artifacts 複製** | 離線可用（最終 fallback） |
| 4 | **Gemini CLI 歸檔** | Gemini CLI 環境用 logs.json/手動摘要 |

### 分派邏輯

```
abdixere-api 可用？ → abdixere-api dump（首選，自動處理 ConnectRPC fallback）
  ↓ 否
Antigravity 運行中？ → ConnectRPC curl（手動）
  ↓ 否
PB 檔案存在？ → PB 離線解密
  ↓ 否
Brain artifacts 存在？ → Brain 複製（最低限度）
  ↓ 否
→ Agent 生成摘要版（絕對最終手段）
```

### ConnectRPC 快速匯出（curl）

> 🔴 **Port 修正（20260314 實測）**：gRPC port = `extension_server_port + 2`（非 +1）。
> 確認方式：`lsof -i -P -n | grep <PID> | grep LISTEN`

```bash
# 1. 取得 PID 與 port
# ℹ️ v1.21.6+：binary 重命名為 language_server_macos_arm（舊版 go-binary）
PID=$(ps aux | grep language_server_macos_arm | grep -v grep | grep "workspace_id file_Users_hc1034_Saki_Studio_Claude" | awk '{print $2}')
GRPC_PORT=$(lsof -i -P -n 2>/dev/null | grep "$PID" | grep LISTEN | head -1 | awk '{print $9}' | cut -d: -f2)
CSRF=$(ps aux | grep "$PID" | grep -o '\-\-csrf_token [^ ]*' | head -1 | awk '{print $2}')

# 2. 提取 trajectory JSON（全文，含系統 prompt）
curl -sk -X POST "https://127.0.0.1:$GRPC_PORT/exa.language_server_pb.LanguageServerService/GetCascadeTrajectory" \
    -H "Content-Type: application/json" -H "Connect-Protocol-Version: 1" \
    -H "x-codeium-csrf-token: $CSRF" -d '{"cascadeId":"UUID"}' > trajectory_steps.json
```

> ⚠️ **ConvertTrajectoryToMarkdown 為官方摘要版**（27KB/291步驟），不含系統 prompt、完整工具參數等。
> 全文 dump 必須從原始 `trajectory_steps.json` 用 Python 提取：

```python
# 全文提取腳本（從 trajectory JSON 生成完整 conversation_dump.md）
import json
with open('trajectory_steps.json') as f:
    data = json.load(f)
steps = data.get('trajectory', {}).get('steps', [])
for step in steps:
    # step.userInput.items → 使用者輸入（含系統 prompt）
    # step.toolCall → 工具呼叫（含完整參數）
    # step.toolResult → 工具結果
    # step.plannerResponse → Agent 回應
    # step.metadata.createdAt → 時間戳
```

> 完整提取腳本見 `references/extraction_methods.md`。

### PB 離線解密

```python
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
key = b"safeCodeiumworldKeYsecretBalloon"  # 32 bytes 硬編碼
nonce, ct = data[:12], data[12:]
plaintext = AESGCM(key).decrypt(nonce, ct, None)  # → Protobuf
```

> ⚠️ 密鑰可能隨版本變更。每次升版需用 `strings` 重新確認。
> ⚠️ v1.21.6 Binary 路徑已變更：`extensions/antigravity/bin/language_server_macos_arm`（舊：`extensions/anthropic.jetski-lsp-v2/dist/go-binary`）

---

## 五、批次歸檔

一次性歸檔大量 Session 時使用。完整流程見 [batch_archive.md](references/batch_archive.md)。

核心：列舉 brain UUID → 批次提取標題 → 建立資料夾 → 複製 artifacts → 更新 INDEX.md。

---

## 六、Session 自動接續（CreatioExNihilo）

| 觸發指標 | 觸發值 |
|----------|--------|
| CHECKPOINT | ≥ 5 |
| Step Id | > 200 |
| 預估剩餘工具呼叫 | > 30 |

流程：
1. 歸檔進度至 ImplementationLog/ + TaskLog/ + Scientia/
2. 觸發 `Promissrum/Workflow/20260215_0836_CreatioExNihilo.Promissrum`
3. 創世提示詞寫入 Scientia + brain/walkthrough.md
4. 通知用戶開新 Session

---

## 七、跨工具對話合併

同一任務跨 Antigravity 與 Gemini CLI 進行時，合併歸檔中以 `sources:` 欄位標註來源。
詳見 [references/extraction_methods.md](references/extraction_methods.md)。

---

## 鐵律

1. **ChatMelius 是歸檔中心** — 不分 Antigravity 或 Gemini CLI
2. **先讀文件再動手** — 不用 grep 替代完整讀取 SKILL.md
3. **新知識寫 Scientia** — 不寫 ChatMelius
4. **hc1034 不可出現在任何對外自動化配置**（用 saki_ios）
5. **CHECKPOINT 高頻時改用 MCP 工具** — 不依賴 run_command
6. **Brain artifacts 是最鮮活的上下文** — 永遠優先於 ChatMelius 歷史
7. **歸檔標註來源** — 區分 Antigravity 與 Gemini CLI 的會話
8. **🔴 Conversation Dump 不可省略** — 協議九/Session Handoff 中 `conversation_dump.md` 為強制產出，未產出 = 歸檔不完整 = 不得結束步驟
9. **🔴 全文 Dump 為原則** — `ConvertTrajectoryToMarkdown` 為官方摘要版，不含系統 prompt。全文 dump 必須從 `trajectory_steps.json` 原始 JSON 提取。日後所有 dump 均須以全文為原則（20260314 新增）
10. **abdixere-api 未編譯時** — 需 `cargo build --release`，屬 API 可用邊界，不視為不可用
