#!/usr/bin/env python3
import json
import sys
import os

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 gemini_cli_dump.py <logs_json_path> [session_id]", file=sys.stderr)
        sys.exit(1)

    logs_path = sys.argv[1]
    target_session = sys.argv[2] if len(sys.argv) > 2 else None

    if not os.path.exists(logs_path):
        print(f"Error: logs.json not found at {logs_path}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(logs_path, 'r', encoding='utf-8') as f:
            content = f.read().strip()
            # Handle potential malformed JSON array or NDJSON
            if content.startswith('[') and content.endswith(']'):
                data = json.loads(content)
            else:
                # Try parsing as NDJSON if it's not a valid array
                lines = content.split('\n')
                data = []
                for line in lines:
                    if line.strip():
                        try:
                            # Strip trailing commas from lines if any
                            clean_line = line.strip()
                            if clean_line.endswith(','):
                                clean_line = clean_line[:-1]
                            data.append(json.loads(clean_line))
                        except json.JSONDecodeError:
                            continue
    except Exception as e:
        print(f"Error reading {logs_path}: {e}", file=sys.stderr)
        sys.exit(1)

    if not target_session:
        # Find the last session ID
        if not data:
            print("No logs found.", file=sys.stderr)
            sys.exit(1)
        target_session = data[-1].get("sessionId")
        if not target_session:
            print("Could not determine the last session ID.", file=sys.stderr)
            sys.exit(1)
        print(f"No session ID provided. Using the latest session: {target_session}", file=sys.stderr)

    session_logs = [entry for entry in data if entry.get("sessionId") == target_session]

    if not session_logs:
        print(f"No logs found for session: {target_session}", file=sys.stderr)
        sys.exit(1)

    # Sort by timestamp just in case
    session_logs.sort(key=lambda x: x.get("timestamp", ""))

    print(f"# Gemini CLI Conversation Dump")
    print(f"**Session ID:** `{target_session}`\n")

    for entry in session_logs:
        role = "User" if entry.get("type") == "user" else "Assistant"
        msg = entry.get("message", "").strip()
        ts = entry.get("timestamp", "")
        
        print(f"### {role} ({ts})")
        print(f"{msg}\n")

if __name__ == '__main__':
    main()
