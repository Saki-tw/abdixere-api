#!/usr/bin/env python3
"""
Antigravity 加密 PB 解密工具
基於 Abdixere Phase 12d (#59) 研究成果與 Machine ID AES-256 解密
用法：python3 decrypt_pb.py <input.pb> [output.bin]
"""

import hashlib
import hmac
import sys
import os
import subprocess

# ===== HKDF 實作 =====
def hkdf_extract(salt, ikm, hash_func=hashlib.sha256):
    if salt is None or len(salt) == 0:
        salt = b'\x00' * hash_func().digest_size
    return hmac.new(salt, ikm, hash_func).digest()

def hkdf_expand(prk, info, length, hash_func=hashlib.sha256):
    hash_len = hash_func().digest_size
    n = (length + hash_len - 1) // hash_len
    okm = b''
    t = b''
    for i in range(1, n + 1):
        t = hmac.new(prk, t + info + bytes([i]), hash_func).digest()
        okm += t
    return okm[:length]

def hkdf(ikm, salt, info, length=32, hash_func=hashlib.sha256):
    prk = hkdf_extract(salt, ikm, hash_func)
    return hkdf_expand(prk, info, length, hash_func)

# ===== AES-256-GCM 解密 =====
def try_decrypt_aes_gcm(key, data, nonce_size=12, tag_size=16):
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        aesgcm = AESGCM(key)
        
        # 方案 1: 合併
        if len(data) >= nonce_size + tag_size:
            nonce = data[:nonce_size]
            ciphertext = data[nonce_size:]
            try:
                plaintext = aesgcm.decrypt(nonce, ciphertext, None)
                return plaintext
            except Exception:
                pass
        
        # 方案 2: 分離
        if len(data) >= nonce_size + tag_size:
            nonce = data[:nonce_size]
            ct = data[nonce_size:-tag_size]
            tag = data[-tag_size:]
            combined = ct + tag
            try:
                plaintext = aesgcm.decrypt(nonce, combined, None)
                return plaintext
            except Exception:
                pass

        return None
    except ImportError:
        print("需要 cryptography 庫: pip install cryptography --break-system-packages")
        sys.exit(1)

def get_machine_id():
    try:
        if sys.platform == 'darwin':
            out = subprocess.check_output(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice']).decode('utf-8')
            for line in out.splitlines():
                if 'IOPlatformUUID' in line:
                    return line.split('"')[3]
    except:
        pass
    return "4FA406D5-0D1E-5D2E-BA26-5363EE0743E2"

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 decrypt_pb.py <input.pb> [output.bin]")
        sys.exit(1)
        
    filepath = sys.argv[1]
    outpath = sys.argv[2] if len(sys.argv) > 2 else f"/tmp/decrypted_{os.path.basename(filepath)}"
    
    with open(filepath, 'rb') as f:
        data = f.read()
    
    machine_id = get_machine_id()
    print(f"使用 Machine ID: {machine_id}")
    
    # 判斷是否為 PB wrapper
    inner_data = data
    if data[0] == 0x0a:
        pos = 1
        length = 0
        shift = 0
        while pos < len(data) and pos < 10:
            b = data[pos]
            length |= (b & 0x7f) << shift
            pos += 1
            shift += 7
            if (b & 0x80) == 0:
                break
        if 0 < length < len(data):
            inner_data = data[pos:pos+length]

    salt_candidates = [b"safeCodeiumworldKeYsecretBalloon", b"", None]
    info_candidates = [b"", b"trajectory", b"implicit trajectory saver", b"conversation", b"proto_saver"]
    ikm_candidates = [
        machine_id.encode('utf-8'),
        machine_id.lower().encode('utf-8'),
        machine_id.upper().encode('utf-8'),
        machine_id.replace('-', '').encode('utf-8'),
        machine_id.replace('-', '').lower().encode('utf-8'),
    ]
    
    datasets = [inner_data, data]
    
    for test_data in datasets:
        for ikm in ikm_candidates:
            for salt in salt_candidates:
                for info in info_candidates:
                    key = hkdf(ikm, salt, info, 32)
                    
                    plaintext = try_decrypt_aes_gcm(key, test_data)
                    if plaintext:
                        print(f"🎉 解密成功! IKM: {ikm}, Salt: {salt}, Info: {info}")
                        with open(outpath, 'wb') as fout:
                            fout.write(plaintext)
                        print(f"已寫入: {outpath}")
                        sys.exit(0)
                        
                    for skip in [1, 2, 3, 4, 5, 6, 8, 10]:
                        if len(test_data) > skip + 28:
                            plaintext = try_decrypt_aes_gcm(key, test_data[skip:])
                            if plaintext:
                                print(f"🎉 解密成功! (Skip {skip}) IKM: {ikm}, Salt: {salt}, Info: {info}")
                                with open(outpath, 'wb') as fout:
                                    fout.write(plaintext)
                                print(f"已寫入: {outpath}")
                                sys.exit(0)
                                
    print("❌ 所有解密組合均失敗。")
    sys.exit(1)

if __name__ == "__main__":
    main()
