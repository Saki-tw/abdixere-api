#!/bin/bash
# backup_brain.sh — Antigravity Brain Artifact 備份到 ChatMelius
# 用法：./backup_brain.sh <conversation-uuid> <序號> <標題> [--dry-run]
# 範例：./backup_brain.sh b3a3b7c0-6b93-4d7f-b574-a82c6591d9bb 197 SakiStar_E2E_Setup
# 範例：./backup_brain.sh b3a3b7c0-... 197 SakiStar_E2E_Setup --dry-run

set -uo pipefail

BRAIN_BASE="$HOME/.gemini/antigravity/brain"
CHATMELIUS="/Users/hc1034/Saki_Studio/Claude/SakiAgentHistory/ChatMelius"

UUID="${1:?用法: $0 <uuid> <序號> <標題> [--dry-run]}"
SEQ="${2:?用法: $0 <uuid> <序號> <標題> [--dry-run]}"
TITLE="${3:?用法: $0 <uuid> <序號> <標題> [--dry-run]}"
DRY_RUN="${4:-}"

BRAIN_DIR="$BRAIN_BASE/$UUID"
TARGET="$CHATMELIUS/${SEQ}_${TITLE}"

# Dry-run 模式
if [ "$DRY_RUN" = "--dry-run" ]; then
    echo "🔍 [DRY-RUN] 預覽模式，不會執行任何操作"
    echo ""
fi

# 驗證 brain 目錄存在
if [ ! -d "$BRAIN_DIR" ]; then
    echo "⚠️ Brain 目錄不存在：$BRAIN_DIR" >&2
    echo "⚠️ 可能處於 Gemini CLI 環境或純對話備份。將跳過 artifacts 複製。"
    
    if [ "$DRY_RUN" != "--dry-run" ]; then
        # 建立 ChatMelius 目標目錄
        mkdir -p "$TARGET"
        echo "📁 建立：$TARGET"
        echo ""
        echo "✅ 完成：已建立目標目錄（無 artifacts）"
        echo ""
        echo "📋 下一步："
        echo "  1. 生成 conversation_dump.md（使用 gemini_cli_dump.py）"
        echo "  2. 生成 handoff_prompt.md"
        echo "  3. 更新 ChatMelius/INDEX.md"
        echo "  4. 更新 ChatMelius/TIMELINE.md"
    fi
    exit 0
fi

# 列出可用的 artifacts
echo "📋 Brain 目錄內容："
ls -la "$BRAIN_DIR"/*.md 2>/dev/null || echo "  （無 .md 檔案）"
echo ""

if [ "$DRY_RUN" = "--dry-run" ]; then
    echo "🔍 [DRY-RUN] 將建立：$TARGET"
    echo "🔍 [DRY-RUN] 預覽結束"
    exit 0
fi

# 建立 ChatMelius 目標目錄
mkdir -p "$TARGET"
echo "📁 建立：$TARGET"

# 複製標準 brain artifacts
COPIED=0
for artifact in task.md implementation_plan.md walkthrough.md; do
    if [ -f "$BRAIN_DIR/$artifact" ]; then
        cp "$BRAIN_DIR/$artifact" "$TARGET/"
        echo "  ✅ $artifact"
        COPIED=$((COPIED + 1))
    else
        echo "  ⚠️ $artifact 不存在（跳過）"
    fi
done

# 複製 walkthrough_*.md（時間戳版本）
for wt in "$BRAIN_DIR"/walkthrough_*.md; do
    if [ -f "$wt" ]; then
        cp "$wt" "$TARGET/"
        echo "  ✅ $(basename "$wt")"
        COPIED=$((COPIED + 1))
    fi
done

# 複製其他自訂 .md artifacts（排除已處理的）
for md in "$BRAIN_DIR"/*.md; do
    if [ -f "$md" ]; then
        basename=$(basename "$md")
        case "$basename" in
            task.md|implementation_plan.md|walkthrough.md|walkthrough_*.md) continue ;;
        esac
        cp "$md" "$TARGET/"
        echo "  ✅ $basename（自訂 artifact）"
        COPIED=$((COPIED + 1))
    fi
done

echo ""
echo "✅ 完成：複製 $COPIED 個 artifact 到 $TARGET"
echo ""
echo "📋 下一步："
echo "  1. 生成 conversation_dump.md（摘要版）"
echo "  2. 生成 handoff_prompt.md"
echo "  3. 更新 ChatMelius/INDEX.md"
echo "  4. 更新 ChatMelius/TIMELINE.md"
