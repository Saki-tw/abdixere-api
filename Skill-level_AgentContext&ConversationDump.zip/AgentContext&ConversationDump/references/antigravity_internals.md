# Antigravity 內部結構參考

> 基於 Antigravity v1.21.6（commit 497c5f20, ideVersion 1.21.6）實測。
> **最後更新**：2026-03-30（Phase 24 成果整合：v1.21.6 品牌重命名 + 523 RPCs + binary 重命名）

## 目錄

1. [~/.gemini/ 頂層結構](#gemini-頂層結構)
2. [antigravity/ 子結構](#antigravity-子結構)
3. [brain/{uuid}/ artifact 結構](#brain-artifact-結構)
4. [conversations/ 對話儲存](#conversations-對話儲存)
5. [knowledge/ 知識系統](#knowledge-知識系統)
6. [應用程式結構](#應用程式結構)
7. [認證管線](#認證管線)
8. [Token Budget 架構](#token-budget-架構)
9. [遠端開發機制](#遠端開發機制)

---

## ~/.gemini/ 頂層結構

```
~/.gemini/
├── antigravity/          # Antigravity Agent 核心資料
├── antigravity-backup/   # 自動備份（舊版 brain 快照）
├── antigravity-browser-profile/  # 內建瀏覽器的 Chromium profile
├── commands/             # 自訂命令（目前為空）
├── history/              # 搜尋/指令歷史
├── policies/             # 策略配置
├── SakiMCP/              # SakiMCP 相關配置與 Promissrum
├── tmp/                  # 暫存檔案
├── GEMINI.md             # 全域使用者規則（Antigravity 載入此檔）
├── google_accounts.json  # Google 帳號資訊
├── installation_id       # 安裝唯一識別碼
├── mcp-oauth-tokens-v2.json  # MCP OAuth tokens
├── oauth_creds.json      # Google OAuth 憑證
├── projects.json         # 專案配置
├── settings.json         # Antigravity 設定
├── skills                # → SakiAgentSkills/Skills（symlink，使用者自訂）
├── state.json            # 應用狀態
└── trustedFolders.json   # 受信任的工作區路徑
```

### 關鍵檔案說明

| 檔案 | 用途 | 安全性 |
|------|------|--------|
| `GEMINI.md` | Agent 系統規則，每次 Session 自動載入 | 公開可編輯 |
| `settings.json` | 編輯器設定、主題、MCP 配置 | 含 MCP server 路徑 |
| `oauth_creds.json` | Google API 認證 | 🔒 敏感 |
| `projects.json` | 已開啟的專案工作區 | 公開 |
| `trustedFolders.json` | 工具可存取的路徑白名單 | 安全相關 |

---

## antigravity/ 子結構

```
~/.gemini/antigravity/
├── annotations/          # 對話註釋（.pbtxt 文字 Protobuf）
│   └── {uuid}.pbtxt      # 含 last_user_view_time 等時間戳
├── brain/                # Agent 對話 artifacts（核心）
│   └── {uuid}/           # 每個對話一個目錄（92+ 個）
├── browser_recordings/   # 瀏覽器操作錄影
├── browserAllowlist.txt  # 瀏覽器允許清單（僅 localhost）
├── code_tracker/         # 工作區檔案追蹤
│   ├── active/           # 活躍工作區（以 {專案名}_{git-hash} 命名）
│   └── history/          # 歷史追蹤（空）
├── context_state/        # 上下文狀態（目前為空）
├── conversations/        # Protobuf 格式的完整對話記錄
├── DEMO_MODE.txt         # 首次啟動時間標記
├── global_workflows/     # 全域工作流定義（workflow.md）
├── html_artifacts/       # HTML artifacts
├── implicit/             # 隱式記憶系統（.pb，跨 Session 學習）
│   └── {uuid}.pb         # 12 個檔案，305B ~ 1.4MB
├── installation_id       # Agent 安裝唯一 ID
├── knowledge/            # 知識庫系統（Knowledge Subagent 維護）
│   ├── knowledge.lock
│   └── {topic-name}/     # 含 metadata.json + artifacts/
├── mcp_config.json       # MCP 伺服器配置
└── playground/           # Agent 臨時程式空間（隨機命名子目錄）
```

---

## brain/ artifact 結構

每個對話在 `brain/{uuid}/` 下生成 artifacts：

```
brain/{uuid}/
├── task.md                # 任務清單（最常見）
├── implementation_plan.md # 實作計劃
├── walkthrough.md         # 完成報告
├── walkthrough_*.md       # 時間戳版本的 walkthrough
└── .system_generated/     # 系統生成（不可直接使用）
    ├── logs/              # 對話日誌
    │   ├── overview.txt   # 對話概覽
    │   └── task_*.txt     # 各任務詳細日誌
    └── steps/             # 工具輸出外部化
        └── {step-id}/
            └── output.txt # MCP 大型回傳結果
```

### Brain 操作注意

- `task.md` 是最鮮活的進度指標，優先於任何 ChatMelius 歷史
- `.system_generated/` 由系統管理，Agent 可讀取 `logs/` 但不應修改
- `steps/` 存放 MCP 外部化結果，讀取時不要再用 `view_file` 完整載入（會抵消外部化效益）
- UUID 格式：`{8}-{4}-{4}-{4}-{12}` 標準 UUID v4

---

## conversations/ 對話儲存

```
conversations/
└── {uuid}.pb             # Protobuf 序列化的完整對話記錄
```

- 格式：Protocol Buffers（二進位）
- 內容：完整的對話 messages、工具呼叫、結果
- 大小：單個 .pb 檔可達數 MB
- ⚠️ Proto schema 未公開，無法直接解析
- 清理策略：低價值對話可刪除 .pb 釋放空間

---

## knowledge/ 知識系統

```
knowledge/
├── knowledge.lock
├── {topic-name}/
│   ├── metadata.json     # 摘要、時間戳、來源引用
│   └── artifacts/
│       └── *.md           # 主題相關的知識文件
└── ...
```

- 由 Antigravity Knowledge Subagent 自動維護
- Agent 可讀取但不應直接修改
- 每次 Session 開始時，KI 摘要會自動注入 system prompt
- 用於跨 Session 持久化知識

---

## 應用程式結構

### 版本資訊（v1.21.6）

| 屬性 | 值 |
|------|-----|
| Bundle ID | `com.google.antigravity` |
| IDE Version | 1.21.6 |
| Commit | `497c5f20` |
| URL Scheme | `antigravity://` |
| Alias CLI | `agy` |
| License | MIT |
| 主執行檔 | `Contents/MacOS/Electron` |
| Extension Gallery | Open VSX（非 Microsoft Marketplace） |
| **擴展目錄名** | **`antigravity`**（舊：`anthropic.jetski-lsp-v2`） |
| **Publisher** | **`google`**（舊：`anthropic`） |
| **Binary 名稱** | **`language_server_macos_arm`**（舊：`go-binary`） |
| **Binary 路徑** | **`extensions/antigravity/bin/`**（舊：`extensions/anthropic.jetski-lsp-v2/dist/`） |
| Binary 大小 | 143.2MB（舊 ~125MB，+14%） |
| gRPC Services | 15 EXA（舊 22，可能合併） |
| gRPC RPCs | **523**（+43% from v1.20.6） |
| google3 路徑行數 | 102,389（舊 122,683，-17%） |
| Extension JS | `dist/extension.js` 3.08MB（舊 3.9MB） |
| mcpOAuthClients | Figma（內建 OAuth） |

### 核心依賴

| 依賴 | 用途 |
|------|------|
| `@connectrpc/connect` | ConnectRPC gRPC 通訊（與 LS 通訊核心） |
| `@bufbuild/protobuf` | Protobuf 序列化/反序列化 |
| `@exa/proto-ts` | Exa 專用 Protobuf TypeScript 綁定（本地模組） |
| `@exa/agent-ui-toolkit` | Agent UI 工具箱（本地模組） |
| `google-auth-library` | Google API 認證 |
| `node-pty` | 終端 PTY 模擬（1.1.0-beta35） |
| `@xterm/*` | 終端 UI（5.6.0-beta.136 系列） |
| `@vscode/ripgrep` | 檔案搜尋 |
| `@vscode/tree-sitter-wasm` | 程式碼解析 |
| `@reduxjs/toolkit` + `react-redux` | 狀態管理 |
| `react-markdown` + `remark-gfm` | Markdown 渲染 |
| `mermaid` | 圖表渲染 |
| `katex` | 數學公式渲染 |
| `lucide-react` | 圖示 |
| `tailwindcss` | UI 樣式（v4） |
| `unleash-client` | Feature Flag 客戶端 |
| `lexical` | 富文字編輯器（用於對話輸入） |

### jetskiAgent

product.json 中的 `jetskiAgent` 相關 checksum 暗示 Agent 核心邏輯封裝於獨立模組：
- `jetskiAgent/main.js` — Agent 主邏輯
- `jetskiMain.tailwind.css` — Agent UI 樣式
- `workbench-jetski-agent.html` — Agent 工作台

### CDP 限制

- Electron 39 的 webview 不再暴露於 `http://localhost:9000/json/list` 的 CDP target 清單
- cascade-panel.html（對話面板）無法透過 CDP 直接存取
- Network.enable 攔截 gRPC stream 為未驗證的替代方向

---

## 認證管線

> Phase 6a 成果（2026-02-21）

### OAuthTokenInfo

Proto：`exa.language_server_pb.OAuthTokenInfo`

| 欄位 # | 名稱 | 類型 |
|:------:|------|------|
| 1 | `access_token` | string |
| 2 | `token_type` | string |
| 3 | `refresh_token` | string |
| 4 | `expiry` | Timestamp |
| 6 | `is_gcp_tos` | bool |

### CSRF Token 流程

```
Extension 啟動 → 產生本地隨機 csrfToken
  ├── CLI flag: --csrf_token → LS 子進程
  ├── gRPC interceptor: header["x-codeium-csrf-token"] → 所有 RPC
  └── HTTP 路由驗證器 → Extension Server HTTP 介面
```

### 認證三階段

| 階段 | 觸發 | 行為 |
|------|------|------|
| ExtensionStartup | 冷啟動 | getOAuthTokenInfo → registerGdmUser |
| AuthenticationEvent | 登入/登出 | getUserStatus → initializeCascadePanelState → getProfileData |
| AuthenticationRefreshEvent | Token 續約 | ExternalAuthProvider.createSession → 重走 AuthenticationEvent |

### API 端點架構

| 端口 | 協議 | 用途 |
|------|------|------|
| httpsPort | gRPC-Connect | AI 功能 RPC |
| httpPort | HTTP | debug/pprof、Unleash proxy |
| lspPort | LSP | 補全/診斷 |

- **無 apiServerUrl 硬編碼**：所有通訊走本地 LS proxy
- **Feature Flag**：Unleash，via `http://localhost:${httpPort}/proxy/unleash`

---

## Token Budget 架構

> Phase 6b 成果（2026-02-21）

### CortexPlanConfig 核心欄位

| 欄位 | 類型 | 說明 |
|------|------|------|
| `planModelName` | string | 計畫模型 |
| `maxTokensPerPlan` | int32 | 每計畫 Token 上限 |
| `maxTokenFraction` | float | 佔 context 比例上限 |
| `chatTemperature` | float | Chat 溫度 |
| `chatCompletionMaxTokens` | int64 | Chat 補全上限 |
| `augmentCommand` | bool | 指令增強 |

### Tool 獨立 Token 限制

| 配置 | 限制欄位 |
|------|---------|
| mQuery | `maxTokensPerMQuery` |
| Subrange | `maxTokensPerSubrange` |
| InspectCluster | `maxTokensPerInspectCluster` |
| KnowledgeBase | `maxTokensPerKnowledgeBaseSearch` |
| SectionJudge | `maxTokens` |

### 三級 Budget 防護

```
CortexPlanConfig（計畫）→ Tool 配置（各工具獨立）→ InternalModel.maxTokens（模型級）
```

---

## 遠端開發機制

> Phase 6b 成果（2026-02-21）

### antigravity-remote-openssh

- Fork 自 Microsoft `open-remote-ssh`
- REH Server CDN：`antigravity-stable.codeiumdata.com`
- URL 模板：`https://antigravity-stable.codeiumdata.com/${os}-reh-${arch}/${quality}/${commit}/antigravity-reh-${os}-${arch}-${ideVersion}.tar.gz`
- 包含自訂 SSH Ask 機制（sshAskClient.js）

### antigravity-remote-wsl

- Fork 自 Microsoft `open-remote-wsl`
- 共用同一 REH Server CDN
- 僅限 Windows 平台
