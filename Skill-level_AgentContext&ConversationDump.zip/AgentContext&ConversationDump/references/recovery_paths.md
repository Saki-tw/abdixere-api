# 各專案上下文恢復路徑速查

使用 ChatMelius 重建前，先嘗試以下快速恢復方法。

## 恢復優先順序

```
Brain 同步 → Scientia → git log → 架構文件 → 入口文件 → ChatMelius（最終手段）
```

## 通用恢復（任何專案）

| 來源 | 路徑 | 說明 |
|------|------|------|
| Brain artifacts | `~/.gemini/antigravity/brain/{id}/task.md` | 最鮮活的進度指標 |
| Brain logs | `~/.gemini/antigravity/brain/{id}/.system_generated/logs/overview.txt` | 對話概覽 |
| Conversations | `~/.gemini/antigravity/conversations/{id}.pb` | Protobuf 完整對話（無法直接讀取） |
| Knowledge | `~/.gemini/antigravity/knowledge/{topic}/` | 知識系統自動萃取 |

## SakiAgentHistory

| 來源 | 路徑 |
|------|------|
| ChatMelius 索引 | `SakiAgentHistory/ChatMelius/INDEX.md` |
| 時間軸 | `SakiAgentHistory/ChatMelius/TIMELINE.md` |
| 注入指南 | `SakiAgentHistory/ChatMelius/CONTEXT_INJECTION_GUIDE.md` |
| 架構 | `SakiAgentHistory/ARCHITECTURE.md` |
| Scientia | `SakiAgentHistory/Scientia/` (30 篇) |

## SakiDeusExAgent

| 來源 | 路徑 |
|------|------|
| Scientia | `SakiDeusExAgent/Scientia/` |
| 架構 | `SakiDeusExAgent/docs/04_explanation/ARCHITECTURE.md` |
| 入口 | `SakiDeusExAgent/CLAUDE.md` |

## SakiMed

| 來源 | 路徑 |
|------|------|
| Scientia | `SakiMed/Scientia/` |
| 架構 | `SakiMed/docs/01_architecture/ARCHITECTURE_CLAUDE.md` |
| 入口 | `SakiMed/CLAUDE.md` |

## SakiMCP

| 來源 | 路徑 |
|------|------|
| Scientia | `SakiMCP/Scientia/` |
| 架構 | `SakiMCP/ARCHITECTURE.md` |
| 入口 | `SakiMCP/CLAUDE.md` |

## SakiWeb / SakiFish

| 來源 | 路徑 |
|------|------|
| SakiWeb 架構 | `SakiWeb/ARCHITECTURE.md` |
| SakiFish 架構 | `SakiFish/ARCHITECTURE.md` |

## 機構通用

| 來源 | 路徑 |
|------|------|
| 上下文遺失指南 | `Claude/docs/02_how-to/20260210_SakiStudio_Agent上下文遺失處理指南.md` |
| 全域入口 | `Claude/GEMINI.md` (v2.1) |
| 全域規範 | `Claude/Promissrum/` |
| 非同步協作 | `Claude/Promissrum/Adventus/20260128_2150_非同步協作架構.Promissrum` |

## ChatMelius 關鍵檔案

當快速恢復不足時，進入 ChatMelius 重建：

| 檔案 | 用途 |
|------|------|
| `INDEX.md` | 會話列表 + UUID + artifact 數量 + 摘要 |
| `TIMELINE.md` | 時間排序定位 |
| `CONTEXT_INJECTION_GUIDE.md` | 三種注入方法（直接複製/CDP/Artifacts） |
| `{序號}_{標題}/task.md` | 單一會話任務進度 |
| `{序號}_{標題}/conversation_dump.md` | 完整對話純文字（若存在） |
| `memories/index.json` | MemoryStore 結構化記憶索引 |
