# CDP 對話提取參考

## 架構變更歷史

| 版本 | Electron | 狀態 | 說明 |
|------|----------|------|------|
| < 1.107 | < 39 | ✅ 可用 | cascade-panel.html webview 透過 CDP 可達 |
| ≥ 1.107 | 39.x | ❌ 失效 | webview 不再暴露於 CDP target 清單 |
| 1.18.3 | 39.2.3 | ❌ 失效 | 確認失效（2026-02-19 build, commit c9b91c2） |

詳見：`SakiAgentHistory/Scientia/20260220_1748_Antigravity1107_CDP對話提取失效研究_Scientia.md`

## 舊版提取流程（< 1.107）

### 1. 啟動 CDP 連線

```bash
# Antigravity 需以 --remote-debugging-port=9000 啟動
curl http://localhost:9000/json/list | jq '.[] | {id, title, url}'
```

### 2. 找到對話面板 target

```bash
curl http://localhost:9000/json/list | jq '.[] | select(.url | contains("cascade"))'
```

### 3. WebSocket 注入 JS 提取對話

透過 CDP `Runtime.evaluate` 注入 JavaScript，提取 DOM 中的對話文字。

### 4. 儲存結果

將提取的純文字儲存為 `conversation_dump.md`。

## v1.18.3 替代研究方向

| 方向 | 可行性 | 說明 |
|------|--------|------|
| `Page.captureSnapshot` | 待驗證 | MHTML 快照可能含對話文字，但需正確的 target |
| `Network.enable` | 待驗證 | 攔截主程序的 gRPC/HTTP stream，可能捕獲對話資料 |
| IndexedDB 存取 | 未研究 | 對話可能暫存於 Electron 的 IndexedDB |
| conversations/*.pb 解析 | 低可行 | Proto schema 未公開，需逆向工程 |
| jetskiAgent/main.js 分析 | 中等 | 分析 Agent 核心邏輯找對話存取 API |
| 摘要替代 | ✅ 可用 | 放棄全文提取，改用 Agent 生成摘要（現行方案） |

### jetskiAgent 發現

product.json 中的 checksums 揭示 Agent 核心模組結構：
- `jetskiAgent/main.js` — Agent 主邏輯入口
- `workbench-jetski-agent.html` — Agent 專用工作台 HTML
- `jetskiMain.tailwind.css` — Agent UI 樣式

這些檔案封裝在 `node_modules.asar` 中，需 `asar extract` 解壓後分析。

## 相關資源

| 資源 | 路徑 |
|------|------|
| CDP 提取方法 | `SakiAgentHistory/docs/03_reference/CDP_EXTRACTION.md` |
| CDP 腳本集 | `SakiAgentHistory/docs/03_reference/CDP_SCRIPTS.md` |
| 資料結構 | `SakiAgentHistory/docs/03_reference/DATA_STRUCTURES.md` |
| 逆向工程報告 | `SakiAgentHistory/docs/04_explanation/ANTIGRAVITY_REVERSE_ENGINEERING.md` |
| 架構研究 Phase 7 | `SakiAgentHistory/Scientia/20260220_0530_Antigravity架構研究_Phase7綜合報告_Scientia.md` |
| CODE_DUMP | `SakiAgentHistory/CODE_DUMP/` |
| 主控台日誌 | `SakiAgentHistory/console-logger/` + `logs/` |
