# 對話全文提取方案詳細指南

從 SKILL.md §四分派至此。根據環境條件選擇適當方案。

---

## 目錄

1. [ConnectRPC API（推薦）](#方案-1connectrpc-api)
2. [abdixere-api CLI](#方案-2abdixere-api-cli)
3. [decrypt_pb.py 離線裸解密](#方案-3decrypt_pbpy)
4. [Gemini CLI 提取](#方案-4gemini-cli)
5. [CDP（已失效）](#方案-5cdp已失效)
6. [摘要版](#方案-6摘要版)

---

## 方案 1：ConnectRPC API

**前提**：Antigravity 正在運行。

### 偵測 Language Server

```bash
PORT=$(ps aux | grep language_server_macos_arm | grep -o '\-\-extension_server_port [0-9]*' | head -1 | awk '{print $2}')
GRPC_PORT=$((PORT + 1))
CSRF=$(ps aux | grep language_server_macos_arm | grep -o '\-\-csrf_token [^ ]*' | head -1 | awk '{print $2}')
```

### 載入 trajectory（明文 JSON）

```bash
curl -sk -X POST "https://127.0.0.1:$GRPC_PORT/exa.language_server_pb.LanguageServerService/LoadTrajectory" \
    -H "Content-Type: application/json" \
    -H "Connect-Protocol-Version: 1" \
    -H "x-codeium-csrf-token: $CSRF" \
    -d "{\"cascadeId\":\"${CONVERSATION_ID}\"}" > conversation_dump.json
```

### 轉 Markdown

```bash
curl -sk -X POST "https://127.0.0.1:$GRPC_PORT/exa.language_server_pb.LanguageServerService/ConvertTrajectoryToMarkdown" \
    -H "Content-Type: application/json" \
    -H "Connect-Protocol-Version: 1" \
    -H "x-codeium-csrf-token: $CSRF" \
    -d "{\"cascadeId\":\"${CONVERSATION_ID}\"}" | python3 -c "import json,sys; print(json.load(sys.stdin).get('markdown',''))" > conversation_dump.md
```

> 詳見 `Agent命令映射/SKILL.md` 取得完整 RPC 列表。

---

## 方案 2：abdixere-api CLI

**前提**：已編譯 `SakiAgentHistory/abdixere-api/`。

```bash
abdixere-api load {cascade-id} > conversation_dump.json
abdixere-api markdown {cascade-id} -o conversation_dump.md
```

---

## 方案 3：decrypt_pb.py

**前提**：Antigravity 可關閉。需 `pip3 install cryptography`。

```bash
python3 scripts/decrypt_pb.py ~/.gemini/antigravity/conversations/{cascade-id}.pb conversation_dump.json
```

> 使用 IOPlatformUUID → HKDF(AES-256-GCM) 靜態解密。輸出未編排 JSON 或 Protobuf 二進位。

---

## 方案 4：Gemini CLI

**適用**：在 Gemini CLI（非 Antigravity）環境下。

```bash
python3 scripts/gemini_cli_dump.py ~/.gemini/tmp/claude/logs.json {session-id} > conversation_dump.md
```

> 不指定 `{session-id}` 時自動提取最後活動 Session。

---

## 方案 5：CDP（已失效）

≥ v1.107 不可用。webview 不再暴露於 CDP target 清單。

詳見 [cdp_extraction.md](cdp_extraction.md)。

---

## 方案 6：摘要版

當以上方案均不可用時，由 Agent 手動撰寫：

```markdown
# conversation_dump — {conversation-id}
> **狀態**：⚠️ 全文提取失敗，以摘要替代

## 對話摘要（依時序）
### Phase N: {名稱}
**用戶需求**: ...
**Agent 行動**: 1. ... 2. ...
**產出**: ...

## 待完成（下一 Session）
1. ...
```
