# 批次歸檔流程

適用於一次性歸檔大量 Session（如 73+ 個歷史對話）。

## 步驟

### 1. 列舉所有 brain UUID

```bash
ls ~/.gemini/antigravity/brain/ | grep -E '^[0-9a-f]{8}-' | head -30
```

### 2. 批次提取標題與日期

```bash
for uuid in $(ls ~/.gemini/antigravity/brain/ | grep -E '^[0-9a-f]{8}-' | head -20); do
  title=$(head -1 ~/.gemini/antigravity/brain/$uuid/task.md 2>/dev/null | sed 's/^# //')
  echo "$uuid: $title"
done
```

### 3. 批次建立 ChatMelius 資料夾

使用 heredoc + while 迴圈，一次建立所有目錄並複製 brain artifacts：

```bash
CHATMELIUS="/Users/hc1034/Saki_Studio/Claude/SakiAgentHistory/ChatMelius"
# 起始序號
START=197

while IFS='|' read -r uuid title; do
  SEQ=$(printf "%03d" $START)
  DIR="$CHATMELIUS/${SEQ}_${title}"
  mkdir -p "$DIR"
  cp ~/.gemini/antigravity/brain/$uuid/task.md "$DIR/" 2>/dev/null
  cp ~/.gemini/antigravity/brain/$uuid/implementation_plan.md "$DIR/" 2>/dev/null
  cp ~/.gemini/antigravity/brain/$uuid/walkthrough.md "$DIR/" 2>/dev/null
  START=$((START + 1))
done << 'EOF'
uuid1|Title_1
uuid2|Title_2
EOF
```

### 4. 更新 INDEX.md

追加新條目表格（UUID, 標題, artifact 數量, 摘要）。

## 實測參考

- Session 52e90abb：62 個 Session 一次性歸檔完成（20260219）
- 耗時約 5-10 分鐘（含 brain artifact 複製）

## 注意事項

- `task.md` 可能不存在（早期 Session 未使用 artifact）
- UUID 排序不代表時序，需以 `ls -lt` 確認
- INDEX.md 更新後須與 TIMELINE.md 保持一致
