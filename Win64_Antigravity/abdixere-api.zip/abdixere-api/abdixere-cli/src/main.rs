use abdixere_core::*;
use abdixere_core::claude;
use abdixere_core::gemini_cli;
use abdixere_core::brain;
use abdixere_core::streaming::StreamEvent;
use clap::Parser;

/// Abdixere API — Antigravity Language Server ConnectRPC 客戶端
/// 基於 Phase 17/20/22/24 研究成果
/// v0.4.0: gRPC port = ext_port + 2, 雙 CSRF, Chrome DevTools MCP
#[derive(Parser, Debug)]
#[command(name = "abdixere-api", about = "Antigravity LS ConnectRPC CLI & History Analyzer")]
struct Args {
    #[command(subcommand)]
    command: Subcommand,
}

#[derive(clap::Subcommand, Debug)]
enum Subcommand {
    /// 列出所有對話
    List,
    /// 載入特定對話的完整 trajectory
    Load {
        /// Cascade ID（對話 UUID）
        cascade_id: String,
    },
    /// 將對話轉為 Markdown
    Markdown {
        /// Cascade ID
        cascade_id: String,
        /// 輸出檔案路徑（預設 stdout）
        #[arg(short, long)]
        output: Option<String>,
    },
    /// 匯出所有對話為 JSON
    ExportAll {
        /// 輸出目錄
        #[arg(short, long, default_value = "./export")]
        dir: String,
    },
    /// 取得使用者狀態
    Status,
    /// 偵測 Language Server 連線參數
    Detect,
    /// 統一 dump：自動偵測來源（ConnectRPC / Brain / Gemini CLI）
    Dump {
        /// Cascade ID 或 Gemini CLI session UUID
        cascade_id: String,
        /// 輸出目錄
        #[arg(short, long)]
        output: Option<String>,
        /// 強制來源：connectrpc, brain, gemini-cli
        #[arg(long)]
        source: Option<String>,
    },
    /// 分析 Claude Code 歷史軌跡
    AnalyzeClaude {
        /// history.jsonl 路徑
        #[arg(short, long, default_value = "~/.claude/history.jsonl")]
        file: String,
        /// 顯示前 N 筆 session
        #[arg(short, long, default_value_t = 20)]
        top: usize,
    },
    /// PB 離線解密
    DecryptPb {
        /// PB 檔案路徑或 glob 模式
        path: String,
        /// 輸出目錄
        #[arg(short, long)]
        output: Option<String>,
    },
    /// 列出 Gemini CLI 對話歷史
    GeminiSessions {
        /// logs.json 路徑（預設掃描所有）
        #[arg(short, long)]
        file: Option<String>,
    },
    /// v1.20.5 新功能：取得模型配置
    ModelConfig,
    /// v1.20.5 新功能：取得實驗狀態
    ExperimentStatus,
    /// v1.20.5 新功能：列出 Cascade 插件
    Plugins,
    /// 即時串流監聽 LS Reactive Updates（NDJSON 輸出）
    Stream {
        /// 串流類型：trajectory, summaries, panel, terminal
        stream_type: String,
        /// Cascade ID（trajectory/panel 需要）
        #[arg(long)]
        cascade_id: Option<String>,
        /// 命令 ID（terminal 需要）
        #[arg(long)]
        command_id: Option<String>,
        /// 最大監聽秒數（預設 60）
        #[arg(long, default_value_t = 60)]
        timeout: u64,
    },
    // === v1.21.6 新增子命令 ===
    /// 取得 user_global 記憶（Rules = Memories）
    Rules,
    /// 取得 MCP Server 狀態
    Mcp,
    /// 取得所有 Skills
    Skills,
    /// 取得 Token 預算
    TokenBase,
    /// Heartbeat（葌通性測試）
    Heartbeat,
    /// 列出所有 LS 實例（含端口、CSRF、Workspace）
    Instances,
    /// 取得 LS 內部診斷日誌
    Diagnostics,
    /// 取得 Chrome DevTools MCP URL
    DevtoolsMcp,
    /// 取得工作區資訊
    Workspaces,
    /// 取得 Unleash/實驗 flags
    Unleash,
}

#[tokio::main]
async fn main() {
    let args = Args::parse();

    // 不需要 LS 的指令
    match &args.command {
        Subcommand::AnalyzeClaude { file, top } => {
            match claude::analyze_claude_history(file) {
                Ok(report) => {
                    println!("====================================");
                    println!("Claude Code History Analysis");
                    println!("Total lines: {}", report.total_lines);
                    println!("Sessions: {}", report.sessions.len());
                    println!("====================================");
                    println!("{:<38} | {:<5} | {}", "Session ID", "Count", "Project");
                    println!("{}", "-".repeat(80));
                    for s in report.sessions.iter().take(*top) {
                        println!("{:<38} | {:<5} | {}", s.session_id, s.message_count, s.project);
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
            return;
        }
        Subcommand::DecryptPb { path, output } => {
            let out = std::path::Path::new(output.as_deref().unwrap_or("."));
            let (ok, fail) = abdixere_core::decrypt::decrypt_pb_batch(path, out);
            println!("\n📊 完成: {} 成功, {} 失敗", ok, fail);
            return;
        }
        Subcommand::GeminiSessions { file } => {
            if let Some(path) = file {
                match gemini_cli::parse_gemini_logs(path) {
                    Ok(logs) => {
                        let sessions = gemini_cli::list_gemini_sessions(&logs);
                        println!("📋 Gemini CLI Sessions（共 {}, {} 則訊息）\n",
                            sessions.len(), logs.len());
                        for s in &sessions {
                            println!("{} | {} 則 | {} ~ {}",
                                &s.session_id[..8], s.message_count,
                                &s.first_timestamp[..10], &s.last_timestamp[..10]);
                        }
                    }
                    Err(e) => eprintln!("❌ {}", e),
                }
            } else {
                let all_logs = gemini_cli::find_all_gemini_logs();
                println!("📂 發現 {} 個 Gemini CLI logs.json", all_logs.len());
                let mappings = gemini_cli::get_project_mappings();
                println!("\n📁 專案映射：");
                for (name, path) in &mappings {
                    println!("  {} → {}", name, path);
                }
                println!("\n📋 logs.json 位置：");
                for log in &all_logs {
                    println!("  {}", log);
                }
            }
            return;
        }
        _ => {}
    }

    // 需要 LS 的指令
    let (port, csrf) = match detect_ls_params().await {
        Some(params) => params,
        None => {
            eprintln!("❌ 無法偵測 Language Server（Antigravity 是否正在運行？）");
            std::process::exit(1);
        }
    };

    let conn = LsConnection::new(port, csrf.clone());

    match args.command {
        Subcommand::Detect => {
            println!("✅ Language Server 偵測成功");
            println!("   gRPC Port: {}", port);
            println!("   CSRF Token: {}", csrf);
            println!("   URL: https://127.0.0.1:{}", port);
        }

        Subcommand::List => {
            match conn.get_all_trajectories().await {
                Ok(data) => {
                    if let Some(summaries) = data.get("trajectorySummaries").and_then(|v| v.as_object()) {
                        println!("📋 對話列表（共 {} 個）\n", summaries.len());
                        let mut entries: Vec<_> = summaries.iter().collect();
                        entries.sort_by(|a, b| {
                            let ta = a.1.get("lastModifiedTime").and_then(|v| v.as_str()).unwrap_or("");
                            let tb = b.1.get("lastModifiedTime").and_then(|v| v.as_str()).unwrap_or("");
                            tb.cmp(ta)
                        });
                        for (id, info) in &entries {
                            let summary = info.get("summary").and_then(|v| v.as_str()).unwrap_or("?");
                            let steps = info.get("stepCount").and_then(|v| v.as_u64()).unwrap_or(0);
                            let time = info.get("lastModifiedTime").and_then(|v| v.as_str()).unwrap_or("?");
                            println!("{} | {:>5} steps | {} | {}",
                                &id[..8.min(id.len())], steps,
                                &time[..10.min(time.len())], summary);
                        }
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Load { cascade_id } => {
            match conn.load_trajectory(&cascade_id).await {
                Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Markdown { cascade_id, output } => {
            match conn.convert_trajectory_to_markdown(&cascade_id).await {
                Ok(data) => {
                    let md = data.get("markdown").and_then(|v| v.as_str()).unwrap_or("");
                    let content = if md.is_empty() {
                        // Fallback to raw JSON
                        match conn.load_trajectory(&cascade_id).await {
                            Ok(traj) => serde_json::to_string_pretty(&traj).unwrap_or_default(),
                            Err(e) => { eprintln!("❌ {}", e); return; }
                        }
                    } else {
                        md.to_string()
                    };
                    match &output {
                        Some(path) => {
                            std::fs::write(path, &content).expect("寫入失敗");
                            println!("✅ 已寫入 {}", path);
                        }
                        None => println!("{}", content),
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::ExportAll { dir } => {
            std::fs::create_dir_all(&dir).expect("建立目錄失敗");
            match conn.get_all_trajectories().await {
                Ok(data) => {
                    if let Some(summaries) = data.get("trajectorySummaries").and_then(|v| v.as_object()) {
                        println!("📦 匯出 {} 個對話至 {}", summaries.len(), dir);
                        for (id, info) in summaries {
                            let summary = info.get("summary").and_then(|v| v.as_str()).unwrap_or("untitled");
                            let safe_name: String = summary.chars()
                                .map(|c| if c.is_alphanumeric() || c == '-' || c == '_' { c } else { '_' })
                                .collect();
                            let filename = format!("{}/{}_{}.json", dir, &id[..8.min(id.len())], &safe_name[..safe_name.len().min(40)]);

                            match conn.load_trajectory(id).await {
                                Ok(traj) => {
                                    let json = serde_json::to_string_pretty(&traj).unwrap_or_default();
                                    std::fs::write(&filename, &json).unwrap_or_else(|e| {
                                        eprintln!("⚠️ 寫入失敗: {}", e);
                                    });
                                    let steps = traj.get("trajectory")
                                        .and_then(|t| t.get("steps"))
                                        .and_then(|s| s.as_array())
                                        .map(|a| a.len()).unwrap_or(0);
                                    println!("  ✅ {} ({} steps)", &id[..8.min(id.len())], steps);
                                }
                                Err(e) => eprintln!("  ❌ {}: {}", &id[..8.min(id.len())], e),
                            }
                        }
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Status => {
            match conn.get_user_status().await {
                Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Dump { cascade_id, output, source } => {
            let home = std::env::var("HOME").unwrap_or_default();
            let brain_dir = format!("{}/.gemini/antigravity/brain/{}", home, cascade_id);
            let out_dir = output.unwrap_or_else(|| ".".to_string());
            std::fs::create_dir_all(&out_dir).ok();

            let forced = source.as_deref().unwrap_or("");
            let mut dumped = false;

            // 來源 1: ConnectRPC
            if !dumped && (forced.is_empty() || forced == "connectrpc") {
                eprintln!("🔍 嘗試 ConnectRPC...");
                if let Ok(data) = conn.get_cascade_trajectory_steps(&cascade_id).await {
                    if let Some(steps) = data.get("steps").and_then(|s| s.as_array()) {
                        if !steps.is_empty() {
                            let json = serde_json::to_string_pretty(&data).unwrap_or_default();
                            let path = format!("{}/trajectory_steps.json", out_dir);
                            std::fs::write(&path, &json).ok();
                            println!("✅ ConnectRPC → {} ({} steps, {} bytes)", path, steps.len(), json.len());
                            dumped = true;
                        }
                    }
                }
            }

            // 來源 2: Brain
            if !dumped && (forced.is_empty() || forced == "brain") {
                eprintln!("🔍 嘗試 Brain artifacts...");
                if let Some(dump) = brain::read_brain_artifacts(&brain_dir) {
                    let md = brain::brain_dump_to_markdown(&dump, &cascade_id);
                    let path = format!("{}/conversation_dump.md", out_dir);
                    std::fs::write(&path, &md).ok();
                    println!("✅ Brain → {} ({} bytes)", path, md.len());
                    dumped = true;
                }
            }

            // 來源 3: Gemini CLI
            if !dumped && (forced.is_empty() || forced == "gemini-cli") {
                eprintln!("🔍 嘗試 Gemini CLI...");
                let all_logs = gemini_cli::find_all_gemini_logs();
                for log_path in &all_logs {
                    if let Ok(logs) = gemini_cli::parse_gemini_logs(log_path) {
                        let matching: Vec<_> = logs.iter()
                            .filter(|e| e.session_id == cascade_id)
                            .collect();
                        if !matching.is_empty() {
                            let json = serde_json::to_string_pretty(&matching).unwrap_or_default();
                            let path = format!("{}/gemini_cli_dump.json", out_dir);
                            std::fs::write(&path, &json).ok();
                            println!("✅ Gemini CLI → {} ({} messages)", path, matching.len());
                            dumped = true;
                            break;
                        }
                    }
                }
            }

            if !dumped {
                eprintln!("❌ 所有來源均不可用");
                std::process::exit(1);
            }
        }

        // === v1.20.5 新功能 ===
        Subcommand::ModelConfig => {
            match conn.get_cascade_model_config_data().await {
                Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::ExperimentStatus => {
            match conn.get_static_experiment_status().await {
                Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Plugins => {
            match conn.get_available_cascade_plugins().await {
                Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Stream { stream_type, cascade_id, command_id, timeout } => {
            use std::sync::atomic::{AtomicBool, Ordering};
            use std::sync::Arc;

            let running = Arc::new(AtomicBool::new(true));
            let r = running.clone();

            // Ctrl+C 優雅退出
            tokio::spawn(async move {
                tokio::signal::ctrl_c().await.ok();
                r.store(false, Ordering::SeqCst);
                eprintln!("\n⏹ 收到中斷信號，正在停止串流...");
            });

            // Timeout
            let running_t = running.clone();
            tokio::spawn(async move {
                tokio::time::sleep(tokio::time::Duration::from_secs(timeout)).await;
                running_t.store(false, Ordering::SeqCst);
                eprintln!("\n⏱ 超過 {}s timeout，正在停止串流...", timeout);
            });

            let event_count = std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0));
            let ec = event_count.clone();
            let running_cb = running.clone();

            let callback = move |event: StreamEvent| -> bool {
                if !running_cb.load(Ordering::SeqCst) {
                    return false;
                }
                match &event {
                    StreamEvent::Data(val) => {
                        let n = ec.fetch_add(1, Ordering::SeqCst) + 1;
                        // NDJSON: 一行一筆 JSON
                        println!("{}", serde_json::to_string(val).unwrap_or_default());
                        eprintln!("📡 [{:>4}] data frame received", n);
                    }
                    StreamEvent::Trailers(val) => {
                        eprintln!("🏁 Stream ended (trailers: {})",
                            serde_json::to_string(val).unwrap_or_default());
                    }
                    StreamEvent::Error(e) => {
                        eprintln!("⚠️ Stream error: {}", e);
                    }
                }
                true
            };

            eprintln!("🔴 開始串流監聽: {} (timeout: {}s, Ctrl+C 停止)", stream_type, timeout);

            let result = match stream_type.as_str() {
                "trajectory" => {
                    conn.stream_trajectory_updates(
                        cascade_id.as_deref(),
                        callback,
                    ).await
                }
                "summaries" => {
                    conn.stream_cascade_summaries(callback).await
                }
                "panel" => {
                    let cid = cascade_id.as_deref().unwrap_or_else(|| {
                        eprintln!("❌ panel 串流需要 --cascade-id 參數");
                        std::process::exit(1);
                    });
                    conn.stream_cascade_panel(cid, callback).await
                }
                "terminal" => {
                    conn.stream_terminal_command(
                        command_id.as_deref(),
                        callback,
                    ).await
                }
                other => {
                    eprintln!("❌ 未知串流類型: {}（可用: trajectory, summaries, panel, terminal）", other);
                    std::process::exit(1);
                }
            };

            let total = event_count.load(std::sync::atomic::Ordering::SeqCst);
            match result {
                Ok(()) => eprintln!("✅ 串流結束，共收到 {} 筆事件", total),
                Err(e) => eprintln!("❌ 串流錯誤: {}（已收到 {} 筆事件）", e, total),
            }
        }

        // === v1.21.6 新功能 ===
        Subcommand::Rules => {
            match conn.get_all_rules().await {
                Ok(data) => {
                    if let Some(memories) = data.get("memories").and_then(|v| v.as_array()) {
                        for m in memories {
                            let id = m.get("memoryId").and_then(|v| v.as_str()).unwrap_or("?");
                            let source = m.get("source").and_then(|v| v.as_str()).unwrap_or("?");
                            let content = m.get("textMemory")
                                .and_then(|t| t.get("content"))
                                .and_then(|v| v.as_str())
                                .unwrap_or("");
                            println!("=== {} ({}) ===\n{}\n", id, source, content);
                        }
                    } else {
                        println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default());
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Mcp => {
            match conn.get_mcp_server_states().await {
                Ok(data) => {
                    if let Some(states) = data.get("states").and_then(|v| v.as_array()) {
                        println!("📡 MCP Servers ({}個)\n", states.len());
                        for s in states {
                            let name = s.get("spec").and_then(|sp| sp.get("serverName")).and_then(|v| v.as_str()).unwrap_or("?");
                            let status = s.get("status").and_then(|v| v.as_str()).unwrap_or("?");
                            println!("  {} [{}]", name, status);
                        }
                    } else {
                        println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default());
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Skills => {
            match conn.get_all_skills().await {
                Ok(data) => {
                    if let Some(skills) = data.get("skills").and_then(|v| v.as_array()) {
                        println!("📚 Skills ({}個)\n", skills.len());
                        for s in skills {
                            let path = s.get("path").and_then(|v| v.as_str()).unwrap_or("?");
                            let name = s.get("name").and_then(|v| v.as_str()).unwrap_or("?");
                            println!("  {} — {}", name, path);
                        }
                    } else {
                        println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default());
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::TokenBase => {
            match conn.get_token_base().await {
                Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Heartbeat => {
            match conn.heartbeat().await {
                Ok(data) => {
                    let ts = data.get("lastExtensionHeartbeat")
                        .and_then(|v| v.as_str())
                        .unwrap_or("?");
                    println!("💚 Heartbeat OK — {}", ts);
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Instances => {
            let instances = abdixere_core::detect_all_ls_instances();
            println!("🔍 LS Instances ({})\n", instances.len());
            for inst in &instances {
                let grpc = inst.extension_server_port + 2;
                println!("  PID {} | WS: {} | ext_port: {} | gRPC: {}",
                    inst.pid, inst.workspace_id, inst.extension_server_port, grpc);
                let csrf_preview = if inst.csrf_token.len() > 12 {
                    format!("{}...{}", &inst.csrf_token[..8], &inst.csrf_token[inst.csrf_token.len()-4..])
                } else { inst.csrf_token.clone() };
                println!("    csrf: {}", csrf_preview);
                if !inst.ext_csrf_token.is_empty() {
                    let ext_preview = if inst.ext_csrf_token.len() > 12 {
                        format!("{}...{}", &inst.ext_csrf_token[..8], &inst.ext_csrf_token[inst.ext_csrf_token.len()-4..])
                    } else { inst.ext_csrf_token.clone() };
                    println!("    ext_csrf: {}", ext_preview);
                }
            }
        }

        Subcommand::Diagnostics => {
            match conn.get_debug_diagnostics().await {
                Ok(data) => {
                    if let Some(diag) = data.get("languageServerDiagnostics") {
                        if let Some(logs) = diag.get("logs").and_then(|v| v.as_str()) {
                            println!("{}", logs);
                        } else {
                            println!("{}", serde_json::to_string_pretty(&diag).unwrap_or_default());
                        }
                    } else {
                        println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default());
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::DevtoolsMcp => {
            let instances = abdixere_core::detect_all_ls_instances();
            let inst = instances.first();
            match inst {
                Some(i) if !i.ext_csrf_token.is_empty() => {
                    match conn.get_chrome_devtools_mcp_url(&i.ext_csrf_token).await {
                        Ok(data) => {
                            let url = data.get("url").and_then(|v| v.as_str()).unwrap_or("?");
                            println!("🌐 Chrome DevTools MCP: {}", url);
                        }
                        Err(e) => eprintln!("❌ {}", e),
                    }
                }
                _ => eprintln!("❌ 無可用的 ext_csrf_token"),
            }
        }

        Subcommand::Workspaces => {
            match conn.get_workspace_infos().await {
                Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        Subcommand::Unleash => {
            match conn.get_static_experiment_status().await {
                Ok(data) => {
                    if let Some(status_arr) = data.get("status").and_then(|v| v.as_array()) {
                        let enabled: Vec<_> = status_arr.iter()
                            .filter(|s| s.get("enabled").and_then(|v| v.as_bool()).unwrap_or(false))
                            .collect();
                        let disabled = status_arr.len() - enabled.len();
                        println!("🧪 Experiments: {} total ({} enabled, {} disabled)\n",
                            status_arr.len(), enabled.len(), disabled);
                        for s in &enabled {
                            let key = s.get("experimentKey").and_then(|v| v.as_str()).unwrap_or("?");
                            println!("  ✅ {}", key);
                        }
                    } else {
                        println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default());
                    }
                }
                Err(e) => eprintln!("❌ {}", e),
            }
        }

        _ => {}
    }
}
