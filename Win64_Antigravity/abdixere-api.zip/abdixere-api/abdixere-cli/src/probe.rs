// Phase 25 RPC 探測腳本 — 用 abdixere-core 做 TLS 連線
use abdixere_core::*;

#[tokio::main]
async fn main() {
    let (port, csrf) = match detect_ls_params().await {
        Some(p) => p,
        None => {
            eprintln!("❌ LS not found");
            return;
        }
    };
    eprintln!("✅ LS at port {} (csrf: {}...)", port, &csrf[..8]);
    let conn = LsConnection::new(port, csrf);

    // GetCascadeModelConfigData
    eprintln!("\n=== GetCascadeModelConfigData ===");
    match conn.get_cascade_model_config_data().await {
        Ok(data) => {
            if let Some(configs) = data.get("clientModelConfigs").and_then(|v| v.as_array()) {
                println!("Models: {} total", configs.len());
                for c in configs {
                    let id = c.get("modelId").and_then(|v| v.as_str()).unwrap_or("?");
                    let name = c.get("displayName").and_then(|v| v.as_str()).unwrap_or("?");
                    let tier = c.get("tierTag").and_then(|v| v.as_str()).unwrap_or("");
                    let category = c.get("category").and_then(|v| v.as_str()).unwrap_or("");
                    println!("  {} | {} [{}] ({})", id, name, tier, category);
                }
            }
            if let Some(default) = data.get("defaultOverrideModelConfig") {
                println!("\nDefault: {}", serde_json::to_string_pretty(default).unwrap_or_default());
            }
        }
        Err(e) => eprintln!("❌ {}", e),
    }

    // GetMcpServerStates
    eprintln!("\n=== GetMcpServerStates ===");
    match conn.get_mcp_server_states().await {
        Ok(data) => {
            if let Some(states) = data.get("states").and_then(|v| v.as_array()) {
                println!("MCP Servers: {}", states.len());
                for s in states {
                    let name = s.get("spec").and_then(|sp| sp.get("serverName")).and_then(|v| v.as_str()).unwrap_or("?");
                    let status = s.get("status").and_then(|v| v.as_str()).unwrap_or("?");
                    let tools: usize = s.get("tools").and_then(|v| v.as_array()).map(|a| a.len()).unwrap_or(0);
                    println!("  {} [{}] ({} tools)", name, status, tools);
                }
            }
        }
        Err(e) => eprintln!("❌ {}", e),
    }

    // GetWorkspaceEditState (size only)
    eprintln!("\n=== GetWorkspaceEditState ===");
    match conn.call_rpc("exa.language_server_pb.LanguageServerService", "GetWorkspaceEditState", &serde_json::json!({})).await {
        Ok(data) => {
            let json = serde_json::to_string(&data).unwrap_or_default();
            println!("Size: {} bytes", json.len());
            if let Some(edits) = data.get("workspaceEdits").and_then(|v| v.as_array()) {
                println!("Repos: {}", edits.len());
                for e in edits {
                    let root = e.get("repoRoot").and_then(|v| v.as_str()).unwrap_or("?");
                    let adds = e.get("numAdditions").and_then(|v| v.as_str()).unwrap_or("0");
                    let dels = e.get("numDeletions").and_then(|v| v.as_str()).unwrap_or("0");
                    println!("  {} (+{} -{}) ", root, adds, dels);
                }
            }
        }
        Err(e) => eprintln!("❌ {}", e),
    }

    // GetCascadeNuxes
    eprintln!("\n=== GetCascadeNuxes ===");
    match conn.call_rpc("exa.language_server_pb.LanguageServerService", "GetCascadeNuxes", &serde_json::json!({})).await {
        Ok(data) => {
            if let Some(nuxes) = data.get("nuxes").and_then(|v| v.as_array()) {
                println!("NUX entries: {}", nuxes.len());
                for n in nuxes.iter().take(5) {
                    let uid = n.get("uid").and_then(|v| v.as_u64()).unwrap_or(0);
                    let loc = n.get("location").and_then(|v| v.as_str()).unwrap_or("?");
                    println!("  uid={} loc={}", uid, loc);
                }
            }
        }
        Err(e) => eprintln!("❌ {}", e),
    }

    // IndexService probe
    eprintln!("\n=== IndexManagementService/GetIndexStates ===");
    match conn.call_rpc("exa.index_pb.IndexManagementService", "GetIndexStates", &serde_json::json!({})).await {
        Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
        Err(e) => eprintln!("❌ {}", e),
    }

    // DevService probe
    eprintln!("\n=== DevService/GetDevInfo ===");
    match conn.call_rpc("exa.dev_pb.DevService", "GetDevInfo", &serde_json::json!({})).await {
        Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
        Err(e) => eprintln!("❌ {}", e),
    }

    // CascadePluginsService
    eprintln!("\n=== CascadePluginsService/GetAvailablePlugins ===");
    match conn.call_rpc("exa.cascade_plugins_pb.CascadePluginsService", "GetAvailablePlugins", &serde_json::json!({})).await {
        Ok(data) => println!("{}", serde_json::to_string_pretty(&data).unwrap_or_default()),
        Err(e) => eprintln!("❌ {}", e),
    }
}
