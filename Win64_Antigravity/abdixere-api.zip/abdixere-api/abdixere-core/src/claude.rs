use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::HashMap;
use chrono::{Local, TimeZone};

/// Claude Code Session 統計
#[derive(Debug, Serialize, Deserialize)]
pub struct SessionInfo {
    pub session_id: String,
    pub project: String,
    pub message_count: usize,
    pub first_timestamp: i64,
    pub last_timestamp: i64,
}

/// Claude Code 歷史分析結果
#[derive(Debug, Serialize)]
pub struct AnalysisReport {
    pub total_lines: usize,
    pub sessions: Vec<SessionInfo>,
}

/// 分析 Claude Code history.jsonl
pub fn analyze_claude_history(path: &str) -> Result<AnalysisReport, String> {
    let real_path = if path.starts_with('~') {
        path.replace('~', &std::env::var("HOME").unwrap_or_default())
    } else {
        path.to_string()
    };

    let content = std::fs::read_to_string(&real_path)
        .map_err(|e| format!("無法讀取 Claude history: {}", e))?;

    let mut sessions: HashMap<String, (usize, String, i64, i64)> = HashMap::new();
    let mut total_lines = 0;

    for line in content.lines() {
        total_lines += 1;
        if let Ok(v) = serde_json::from_str::<Value>(line) {
            let sid = v.get("sessionId").and_then(|s| s.as_str()).unwrap_or("unknown").to_string();
            let project = v.get("project").and_then(|s| s.as_str()).unwrap_or("unknown").to_string();
            let ts = v.get("timestamp").and_then(|t| t.as_i64()).unwrap_or(0);

            let entry = sessions.entry(sid).or_insert((0, project, ts, ts));
            entry.0 += 1;
            if ts < entry.2 { entry.2 = ts; }
            if ts > entry.3 { entry.3 = ts; }
        }
    }

    let mut sorted: Vec<SessionInfo> = sessions.into_iter()
        .map(|(sid, (count, project, first, last))| SessionInfo {
            session_id: sid,
            project,
            message_count: count,
            first_timestamp: first,
            last_timestamp: last,
        })
        .collect();
    sorted.sort_by(|a, b| b.message_count.cmp(&a.message_count));

    Ok(AnalysisReport {
        total_lines,
        sessions: sorted,
    })
}

/// 格式化時間戳為本地時間字串
pub fn format_timestamp(ts: i64) -> String {
    Local.timestamp_millis_opt(ts)
        .single()
        .map(|dt| dt.format("%Y-%m-%d %H:%M:%S").to_string())
        .unwrap_or_else(|| "unknown".to_string())
}
