//! ConnectRPC ServerStream 客戶端
//!
//! 基於 Scientia #88 研究：ConnectRPC envelope framing 協議
//! - 5 bytes header: 1 byte flags + 4 bytes big-endian payload length
//! - flags 0x00 = data frame, 0x02 = trailers frame
//! - content-type: application/connect+json (streaming)

use bytes::{Buf, BytesMut};
use futures_util::StreamExt;
use serde_json::Value;

use crate::LsConnection;

/// ConnectRPC envelope flags
const FLAG_DATA: u8 = 0x00;
const FLAG_TRAILERS: u8 = 0x02;

/// ConnectRPC envelope header 長度
const ENVELOPE_HEADER_LEN: usize = 5;

/// 串流事件類型
#[derive(Debug, Clone)]
pub enum StreamEvent {
    /// 資料幀 — 包含一筆 JSON payload
    Data(Value),
    /// Trailers 幀 — 串流結束標記（可能包含 error 資訊）
    Trailers(Value),
    /// 解析錯誤
    Error(String),
}

/// 從 buffer 中嘗試解析一個 ConnectRPC envelope
///
/// 成功回傳 `Some((flags, payload_bytes))`，buffer 不足回傳 `None`
fn try_parse_envelope(buf: &mut BytesMut) -> Option<(u8, Vec<u8>)> {
    if buf.len() < ENVELOPE_HEADER_LEN {
        return None;
    }

    let flags = buf[0];
    let payload_len = u32::from_be_bytes([buf[1], buf[2], buf[3], buf[4]]) as usize;
    let total_len = ENVELOPE_HEADER_LEN + payload_len;

    if buf.len() < total_len {
        return None;
    }

    // 消費 header
    buf.advance(ENVELOPE_HEADER_LEN);
    // 消費 payload
    let payload = buf.split_to(payload_len).to_vec();
    Some((flags, payload))
}

/// 將 envelope payload 轉為 StreamEvent
fn envelope_to_event(flags: u8, payload: Vec<u8>) -> StreamEvent {
    match flags {
        FLAG_DATA => {
            match serde_json::from_slice::<Value>(&payload) {
                Ok(val) => StreamEvent::Data(val),
                Err(e) => StreamEvent::Error(format!("JSON parse error in data frame: {}", e)),
            }
        }
        FLAG_TRAILERS => {
            match serde_json::from_slice::<Value>(&payload) {
                Ok(val) => StreamEvent::Trailers(val),
                Err(_) => {
                    // Trailers 可能是空的或非 JSON
                    let text = String::from_utf8_lossy(&payload).to_string();
                    StreamEvent::Trailers(Value::String(text))
                }
            }
        }
        _ => StreamEvent::Error(format!("Unknown envelope flag: 0x{:02x}", flags)),
    }
}

impl LsConnection {
    /// 低層級 ConnectRPC ServerStream 呼叫
    ///
    /// 發送 POST 請求並以 `bytes_stream()` 增量讀取回應，
    /// 解析 5-byte envelope framing 後透過 callback 回傳每筆事件。
    ///
    /// # Arguments
    /// * `service` — 完整服務路徑（如 `exa.language_server_pb.LanguageServerService`）
    /// * `method` — RPC 方法名
    /// * `body` — 請求 JSON body
    /// * `callback` — 每收到一筆 `StreamEvent` 時呼叫；回傳 `false` 可提前終止串流
    pub async fn stream_rpc<F>(
        &self,
        service: &str,
        method: &str,
        body: &Value,
        mut callback: F,
    ) -> Result<(), String>
    where
        F: FnMut(StreamEvent) -> bool + Send,
    {
        let url = format!(
            "https://127.0.0.1:{}/{}/{}",
            self.port, service, method
        );

        let resp = self.client
            .post(&url)
            .header("Content-Type", "application/connect+json")
            .header("Connect-Protocol-Version", "1")
            .header("Connect-Timeout-Ms", "120000")
            .header("x-codeium-csrf-token", &self.csrf_token)
            .json(body)
            .send()
            .await
            .map_err(|e| format!("HTTP error: {}", e))?;

        let status = resp.status();
        if !status.is_success() {
            let text = resp.text().await.unwrap_or_default();
            return Err(format!("HTTP {}: {}", status, text));
        }

        // 使用 bytes_stream() 增量讀取
        let mut stream = resp.bytes_stream();
        let mut buf = BytesMut::new();

        while let Some(chunk_result) = stream.next().await {
            let chunk = chunk_result
                .map_err(|e| format!("Stream read error: {}", e))?;
            buf.extend_from_slice(&chunk);

            // 從 buffer 中盡可能解析所有完整的 envelope
            loop {
                match try_parse_envelope(&mut buf) {
                    Some((flags, payload)) => {
                        let event = envelope_to_event(flags, payload);
                        let is_trailers = matches!(event, StreamEvent::Trailers(_));
                        let should_continue = callback(event);

                        // Trailers frame 表示串流結束
                        if is_trailers || !should_continue {
                            return Ok(());
                        }
                    }
                    None => break, // buffer 不足，等待下一個 chunk
                }
            }
        }

        // 連線關閉但未收到 trailers — 可能是異常斷線
        if !buf.is_empty() {
            callback(StreamEvent::Error(format!(
                "Stream ended with {} bytes remaining in buffer",
                buf.len()
            )));
        }

        Ok(())
    }

    // === LanguageServerService Streaming RPCs ===

    /// 即時監聽使用者 trajectory 更新
    ///
    /// 串流推送 Cascade 步驟變更事件，可用於：
    /// - 即時監控 Cascade 對話進度
    /// - 自動觸發後處理（如自動 dump）
    pub async fn stream_trajectory_updates<F>(
        &self,
        cascade_id: Option<&str>,
        callback: F,
    ) -> Result<(), String>
    where
        F: FnMut(StreamEvent) -> bool + Send,
    {
        let body = match cascade_id {
            Some(id) => serde_json::json!({"cascadeId": id}),
            None => serde_json::json!({}),
        };
        self.stream_rpc(
            "exa.language_server_pb.LanguageServerService",
            "StreamUserTrajectoryReactiveUpdates",
            &body,
            callback,
        ).await
    }

    /// 即時監聽 Cascade 摘要變更
    ///
    /// 追蹤對話列表的即時更新（新增/修改/刪除）
    pub async fn stream_cascade_summaries<F>(
        &self,
        callback: F,
    ) -> Result<(), String>
    where
        F: FnMut(StreamEvent) -> bool + Send,
    {
        self.stream_rpc(
            "exa.language_server_pb.LanguageServerService",
            "StreamCascadeSummariesReactiveUpdates",
            &serde_json::json!({}),
            callback,
        ).await
    }

    /// 即時監聽 Cascade 面板更新
    ///
    /// 追蹤特定 Cascade 面板的狀態變更
    pub async fn stream_cascade_panel<F>(
        &self,
        cascade_id: &str,
        callback: F,
    ) -> Result<(), String>
    where
        F: FnMut(StreamEvent) -> bool + Send,
    {
        self.stream_rpc(
            "exa.language_server_pb.LanguageServerService",
            "StreamCascadePanelReactiveUpdates",
            &serde_json::json!({"cascadeId": cascade_id}),
            callback,
        ).await
    }

    /// 即時監聽終端命令串流
    ///
    /// 監聽 Agent 執行的終端命令與輸出
    pub async fn stream_terminal_command<F>(
        &self,
        command_id: Option<&str>,
        callback: F,
    ) -> Result<(), String>
    where
        F: FnMut(StreamEvent) -> bool + Send,
    {
        let body = match command_id {
            Some(id) => serde_json::json!({"commandId": id}),
            None => serde_json::json!({}),
        };
        self.stream_rpc(
            "exa.language_server_pb.LanguageServerService",
            "StreamTerminalShellCommand",
            &body,
            callback,
        ).await
    }

    /// 即時監聽 Agent 狀態更新（v1.20.6 新增）
    ///
    /// 追蹤 Agent 執行狀態的即時變更
    pub async fn stream_agent_state_updates<F>(
        &self,
        callback: F,
    ) -> Result<(), String>
    where
        F: FnMut(StreamEvent) -> bool + Send,
    {
        self.stream_rpc(
            "exa.language_server_pb.LanguageServerService",
            "StreamAgentStateUpdates",
            &serde_json::json!({}),
            callback,
        ).await
    }
}

// === 單元測試 ===

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_envelope_data_frame() {
        // flags=0x00, payload_len=13 ({"key":"val"})
        let payload = b"{\"key\":\"val\"}";
        let len = (payload.len() as u32).to_be_bytes();
        let mut buf = BytesMut::new();
        buf.extend_from_slice(&[FLAG_DATA, len[0], len[1], len[2], len[3]]);
        buf.extend_from_slice(payload);

        let result = try_parse_envelope(&mut buf);
        assert!(result.is_some());
        let (flags, data) = result.unwrap();
        assert_eq!(flags, FLAG_DATA);
        assert_eq!(data, payload.to_vec());
        assert!(buf.is_empty());
    }

    #[test]
    fn test_parse_envelope_trailers_frame() {
        let payload = b"{}";
        let len = (payload.len() as u32).to_be_bytes();
        let mut buf = BytesMut::new();
        buf.extend_from_slice(&[FLAG_TRAILERS, len[0], len[1], len[2], len[3]]);
        buf.extend_from_slice(payload);

        let result = try_parse_envelope(&mut buf);
        assert!(result.is_some());
        let (flags, _) = result.unwrap();
        assert_eq!(flags, FLAG_TRAILERS);
    }

    #[test]
    fn test_parse_envelope_insufficient_header() {
        let mut buf = BytesMut::from(&[0x00, 0x00, 0x00][..]);
        assert!(try_parse_envelope(&mut buf).is_none());
        assert_eq!(buf.len(), 3); // buffer 未被消費
    }

    #[test]
    fn test_parse_envelope_insufficient_payload() {
        // header 說有 100 bytes payload，但只有 5 bytes
        let mut buf = BytesMut::new();
        buf.extend_from_slice(&[0x00, 0x00, 0x00, 0x00, 100]);
        buf.extend_from_slice(b"short");

        assert!(try_parse_envelope(&mut buf).is_none());
        assert_eq!(buf.len(), 10); // buffer 未被消費
    }

    #[test]
    fn test_parse_envelope_multiple_frames() {
        let p1 = b"{\"a\":1}";
        let p2 = b"{\"b\":2}";
        let len1 = (p1.len() as u32).to_be_bytes();
        let len2 = (p2.len() as u32).to_be_bytes();

        let mut buf = BytesMut::new();
        // Frame 1
        buf.extend_from_slice(&[FLAG_DATA, len1[0], len1[1], len1[2], len1[3]]);
        buf.extend_from_slice(p1);
        // Frame 2
        buf.extend_from_slice(&[FLAG_DATA, len2[0], len2[1], len2[2], len2[3]]);
        buf.extend_from_slice(p2);

        let r1 = try_parse_envelope(&mut buf);
        assert!(r1.is_some());
        assert_eq!(r1.unwrap().1, p1.to_vec());

        let r2 = try_parse_envelope(&mut buf);
        assert!(r2.is_some());
        assert_eq!(r2.unwrap().1, p2.to_vec());

        assert!(buf.is_empty());
    }

    #[test]
    fn test_parse_envelope_zero_length_payload() {
        let mut buf = BytesMut::new();
        buf.extend_from_slice(&[FLAG_DATA, 0x00, 0x00, 0x00, 0x00]);

        let result = try_parse_envelope(&mut buf);
        assert!(result.is_some());
        let (flags, data) = result.unwrap();
        assert_eq!(flags, FLAG_DATA);
        assert!(data.is_empty());
    }

    #[test]
    fn test_envelope_to_event_data() {
        let payload = b"{\"step\":42}";
        let event = envelope_to_event(FLAG_DATA, payload.to_vec());
        match event {
            StreamEvent::Data(val) => {
                assert_eq!(val.get("step").and_then(|v| v.as_u64()), Some(42));
            }
            _ => panic!("Expected Data event"),
        }
    }

    #[test]
    fn test_envelope_to_event_trailers() {
        let payload = b"{}";
        let event = envelope_to_event(FLAG_TRAILERS, payload.to_vec());
        assert!(matches!(event, StreamEvent::Trailers(_)));
    }

    #[test]
    fn test_envelope_to_event_unknown_flag() {
        let event = envelope_to_event(0xFF, vec![]);
        assert!(matches!(event, StreamEvent::Error(_)));
    }

    #[test]
    fn test_envelope_to_event_invalid_json_data() {
        let payload = b"not json";
        let event = envelope_to_event(FLAG_DATA, payload.to_vec());
        assert!(matches!(event, StreamEvent::Error(_)));
    }

    #[test]
    fn test_envelope_to_event_invalid_json_trailers() {
        // Trailers 即使 JSON 無效也不應 Error，而是回退為 String
        let payload = b"not json trailers";
        let event = envelope_to_event(FLAG_TRAILERS, payload.to_vec());
        match event {
            StreamEvent::Trailers(Value::String(s)) => {
                assert_eq!(s, "not json trailers");
            }
            _ => panic!("Expected Trailers(String) event"),
        }
    }
}
