use serde::{Deserialize, Serialize};
use std::collections::HashMap;

/// Gemini CLI 對話日誌條目
/// 基於 Scientia #86 分析
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LogEntry {
    #[serde(rename = "sessionId")]
    pub session_id: String,
    #[serde(rename = "messageId")]
    pub message_id: u64,
    #[serde(rename = "type")]
    pub entry_type: String,
    pub message: String,
    pub timestamp: String,
}

/// Gemini CLI Session 摘要
#[derive(Debug, Serialize)]
pub struct GeminiSession {
    pub session_id: String,
    pub message_count: usize,
    pub first_timestamp: String,
    pub last_timestamp: String,
}

/// 解析 Gemini CLI logs.json
pub fn parse_gemini_logs(path: &str) -> Result<Vec<LogEntry>, String> {
    let real_path = if path.starts_with('~') {
        path.replace('~', &std::env::var("HOME").unwrap_or_default())
    } else {
        path.to_string()
    };

    let content = std::fs::read_to_string(&real_path)
        .map_err(|e| format!("無法讀取 Gemini CLI logs: {}", e))?;

    serde_json::from_str::<Vec<LogEntry>>(&content)
        .map_err(|e| format!("JSON 解析失敗: {}", e))
}

/// 列出所有 Gemini CLI Sessions
pub fn list_gemini_sessions(logs: &[LogEntry]) -> Vec<GeminiSession> {
    let mut sessions: HashMap<String, (usize, String, String)> = HashMap::new();

    for entry in logs {
        let info = sessions.entry(entry.session_id.clone())
            .or_insert((0, entry.timestamp.clone(), entry.timestamp.clone()));
        info.0 += 1;
        if entry.timestamp < info.1 { info.1 = entry.timestamp.clone(); }
        if entry.timestamp > info.2 { info.2 = entry.timestamp.clone(); }
    }

    let mut result: Vec<GeminiSession> = sessions.into_iter()
        .map(|(sid, (count, first, last))| GeminiSession {
            session_id: sid,
            message_count: count,
            first_timestamp: first,
            last_timestamp: last,
        })
        .collect();
    result.sort_by(|a, b| b.last_timestamp.cmp(&a.last_timestamp));
    result
}

/// 掃描 ~/.gemini/tmp/ 下所有 logs.json
pub fn find_all_gemini_logs() -> Vec<String> {
    let home = std::env::var("HOME").unwrap_or_default();
    let tmp_dir = format!("{}/.gemini/tmp", home);
    let mut logs = Vec::new();

    if let Ok(entries) = std::fs::read_dir(&tmp_dir) {
        for entry in entries.flatten() {
            let log_path = entry.path().join("logs.json");
            if log_path.exists() {
                logs.push(log_path.to_string_lossy().to_string());
            }
        }
    }

    logs
}

/// 讀取 .project_root 映射
pub fn get_project_mappings() -> HashMap<String, String> {
    let home = std::env::var("HOME").unwrap_or_default();
    let history_dir = format!("{}/.gemini/history", home);
    let mut mappings = HashMap::new();

    if let Ok(entries) = std::fs::read_dir(&history_dir) {
        for entry in entries.flatten() {
            if entry.file_type().map(|t| t.is_dir()).unwrap_or(false) {
                let root_file = entry.path().join(".project_root");
                if let Ok(content) = std::fs::read_to_string(&root_file) {
                    let name = entry.file_name().to_string_lossy().to_string();
                    mappings.insert(name, content.trim().to_string());
                }
            }
        }
    }

    mappings
}
