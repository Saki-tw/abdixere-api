use std::process::Command;
use crate::LsConnection;

/// 從 ps 中偵測 Language Server 連線參數
/// v1.21.6: gRPC 埠 = extension_server_port + 2（非 +1）
/// v1.21.6: 雙 CSRF 架構 — csrf_token (LS) + extension_server_csrf_token (ExtServer)
/// 偵測策略: 優先用 +2 做快速確認，lsof 作為 fallback
pub async fn detect_ls_params() -> Option<(u16, String)> {
    let instances = detect_all_ls_instances();
    if instances.is_empty() { return None; }

    // 優先嘗試每個 instance 的 ext_port + 2
    for inst in &instances {
        let grpc_port = inst.extension_server_port + 2;
        let conn = LsConnection::new(grpc_port, inst.csrf_token.clone());
        if conn.heartbeat().await.is_ok() {
            return Some((grpc_port, inst.csrf_token.clone()));
        }
    }

    // Fallback: lsof 探測
    for inst in &instances {
        let lsof = Command::new("lsof")
            .args(["-p", &inst.pid.to_string(), "-P", "-n"])
            .output()
            .ok()?;
        let lsof_output = String::from_utf8_lossy(&lsof.stdout);

        let mut candidate_ports = Vec::new();
        for line in lsof_output.lines() {
            if !line.starts_with("language_") { continue; }
            if !line.contains("LISTEN") { continue; }
            if let Some(port_str) = line.split(':').last() {
                if let Some(port) = port_str.split_whitespace().next()
                    .and_then(|s| s.parse::<u16>().ok()) {
                    candidate_ports.push(port);
                }
            }
        }

        for port in &candidate_ports {
            let conn = LsConnection::new(*port, inst.csrf_token.clone());
            if conn.heartbeat().await.is_ok() {
                return Some((*port, inst.csrf_token.clone()));
            }
        }
    }

    None
}

/// LS 實例資訊
pub struct LsInstance {
    pub pid: u32,
    pub workspace_id: String,
    pub extension_server_port: u16,
    pub csrf_token: String,
    pub ext_csrf_token: String,
}

/// 偵測所有運行中的 LS 實例
pub fn detect_all_ls_instances() -> Vec<LsInstance> {
    let output = match Command::new("ps").args(["aux"]).output() {
        Ok(o) => o,
        Err(_) => return vec![],
    };
    let ps_output = String::from_utf8_lossy(&output.stdout);
    let mut instances = Vec::new();

    for line in ps_output.lines() {
        if !line.contains("language_server_macos_arm") { continue; }
        if line.contains("grep") { continue; }

        let parts: Vec<&str> = line.split_whitespace().collect();
        let pid = parts.get(1).and_then(|s| s.parse::<u32>().ok()).unwrap_or(0);
        if pid == 0 { continue; }

        let extract = |flag: &str| -> String {
            line.split(flag)
                .nth(1)
                .and_then(|s| s.split_whitespace().next())
                .unwrap_or("")
                .to_string()
        };

        let csrf_token = extract("--csrf_token ");
        let ext_csrf_token = extract("--extension_server_csrf_token ");
        let ext_port_str = extract("--extension_server_port ");
        let workspace_id = extract("--workspace_id ");

        let ext_port = ext_port_str.parse::<u16>().unwrap_or(0);
        if ext_port == 0 || csrf_token.is_empty() { continue; }

        instances.push(LsInstance {
            pid,
            workspace_id,
            extension_server_port: ext_port,
            csrf_token,
            ext_csrf_token,
        });
    }
    instances
}

/// 取得 LS 進程資訊（PID, 命令行）
pub fn get_ls_process_info() -> Option<(u32, String)> {
    let output = Command::new("ps")
        .args(["aux"])
        .output()
        .ok()?;
    let ps_output = String::from_utf8_lossy(&output.stdout);

    for line in ps_output.lines() {
        if !line.contains("language_server_macos_arm") { continue; }
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() > 1 {
            let pid = parts[1].parse::<u32>().unwrap_or(0);
            return Some((pid, line.to_string()));
        }
    }
    None
}
