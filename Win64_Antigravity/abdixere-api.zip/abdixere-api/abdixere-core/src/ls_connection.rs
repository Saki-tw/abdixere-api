use reqwest::Client;
use serde_json::Value;

/// Antigravity Language Server ConnectRPC 連接
/// 基於 Phase 17 研究成果：HTTPS + ConnectRPC JSON + x-codeium-csrf-token
pub struct LsConnection {
    pub port: u16,
    pub csrf_token: String,
    pub(crate) client: Client,
}

impl LsConnection {
    pub fn new(port: u16, csrf_token: String) -> Self {
        let client = Client::builder()
            .danger_accept_invalid_certs(true)
            .build()
            .expect("Failed to create HTTP client");
        Self { port, csrf_token, client }
    }

    /// 底層 ConnectRPC 呼叫
    pub async fn call_rpc(&self, service: &str, method: &str, body: &Value) -> Result<Value, String> {
        let url = format!(
            "https://127.0.0.1:{}/{}/{}",
            self.port, service, method
        );
        let resp = self.client
            .post(&url)
            .header("Content-Type", "application/json")
            .header("Connect-Protocol-Version", "1")
            .header("x-codeium-csrf-token", &self.csrf_token)
            .json(body)
            .send()
            .await
            .map_err(|e| format!("HTTP error: {}", e))?;

        let status = resp.status();
        let text = resp.text().await.map_err(|e| format!("Read error: {}", e))?;

        if !status.is_success() {
            return Err(format!("HTTP {}: {}", status, text));
        }

        serde_json::from_str(&text).map_err(|e| format!("JSON parse error: {}", e))
    }

    // === LanguageServerService RPCs ===

    pub async fn get_all_trajectories(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetAllCascadeTrajectories",
            &serde_json::json!({}),
        ).await
    }

    pub async fn load_trajectory(&self, cascade_id: &str) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "LoadTrajectory",
            &serde_json::json!({"cascadeId": cascade_id}),
        ).await
    }

    pub async fn convert_trajectory_to_markdown(&self, cascade_id: &str) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "ConvertTrajectoryToMarkdown",
            &serde_json::json!({"cascadeId": cascade_id}),
        ).await
    }

    pub async fn get_cascade_trajectory_steps(&self, cascade_id: &str) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetCascadeTrajectorySteps",
            &serde_json::json!({"cascadeId": cascade_id}),
        ).await
    }

    pub async fn get_user_status(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetUserStatus",
            &serde_json::json!({}),
        ).await
    }

    // === v1.20.5 新增 RPCs ===

    pub async fn get_cascade_trajectory_generator_metadata(&self, cascade_id: &str) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetCascadeTrajectoryGeneratorMetadata",
            &serde_json::json!({"cascadeId": cascade_id}),
        ).await
    }

    pub async fn get_artifact_snapshots(&self, cascade_id: &str) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetArtifactSnapshots",
            &serde_json::json!({"cascadeId": cascade_id}),
        ).await
    }

    pub async fn get_cascade_model_config_data(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetCascadeModelConfigData",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_static_experiment_status(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetStaticExperimentStatus",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_available_cascade_plugins(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetAvailableCascadePlugins",
            &serde_json::json!({}),
        ).await
    }

    pub async fn accept_terms_of_service(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "AcceptTermsOfService",
            &serde_json::json!({}),
        ).await
    }

    // === v1.20.6 新增 RPCs ===

    pub async fn get_all_skills(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetAllSkills",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_all_workflows(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetAllWorkflows",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_all_rules(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetAllRules",
            &serde_json::json!({}),
        ).await
    }

    pub async fn list_mcp_prompts(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "ListMcpPrompts",
            &serde_json::json!({}),
        ).await
    }

    pub async fn list_mcp_resources(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "ListMcpResources",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_mcp_prompt(&self, name: &str) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetMcpPrompt",
            &serde_json::json!({"name": name}),
        ).await
    }

    pub async fn dump_flight_recorder(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "DumpFlightRecorder",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_agent_scripts(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetAgentScripts",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_code_validation_states(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetCodeValidationStates",
            &serde_json::json!({}),
        ).await
    }

    // === v1.21.6 新增 RPCs ===

    pub async fn heartbeat(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "Heartbeat",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_mcp_server_states(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetMcpServerStates",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_unleash_data(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetUnleashData",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_profile_data(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetProfileData",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_debug_diagnostics(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetDebugDiagnostics",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_token_base(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetTokenBase",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_workspace_infos(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetWorkspaceInfos",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_working_directories(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetWorkingDirectories",
            &serde_json::json!({}),
        ).await
    }

    pub async fn get_repo_infos(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "GetRepoInfos",
            &serde_json::json!({}),
        ).await
    }

    pub async fn well_supported_languages(&self) -> Result<Value, String> {
        self.call_rpc(
            "exa.language_server_pb.LanguageServerService",
            "WellSupportedLanguages",
            &serde_json::json!({}),
        ).await
    }

    // === ExtensionServerService RPCs (需要 ext_csrf_token) ===

    pub async fn call_ext_rpc(&self, method: &str, body: &Value, ext_csrf: &str) -> Result<Value, String> {
        let url = format!(
            "https://127.0.0.1:{}/exa.extension_server_pb.ExtensionServerService/{}",
            self.port, method
        );
        let resp = self.client
            .post(&url)
            .header("Content-Type", "application/json")
            .header("Connect-Protocol-Version", "1")
            .header("x-codeium-csrf-token", ext_csrf)
            .json(body)
            .send()
            .await
            .map_err(|e| format!("HTTP error: {}", e))?;

        let status = resp.status();
        let text = resp.text().await.map_err(|e| format!("Read error: {}", e))?;

        if !status.is_success() {
            return Err(format!("HTTP {}: {}", status, text));
        }

        serde_json::from_str(&text).map_err(|e| format!("JSON parse error: {}", e))
    }

    pub async fn get_chrome_devtools_mcp_url(&self, ext_csrf: &str) -> Result<Value, String> {
        self.call_ext_rpc("GetChromeDevtoolsMcpUrl", &serde_json::json!({}), ext_csrf).await
    }

    pub async fn check_terminal_shell_support(&self, ext_csrf: &str) -> Result<Value, String> {
        self.call_ext_rpc("CheckTerminalShellSupport", &serde_json::json!({}), ext_csrf).await
    }
}
