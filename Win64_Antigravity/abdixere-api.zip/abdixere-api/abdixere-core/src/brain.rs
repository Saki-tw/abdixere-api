use std::path::Path;

/// Brain artifacts dump 結果
#[derive(Debug)]
pub struct BrainDump {
    pub task_md: Option<String>,
    pub walkthrough_md: Option<String>,
    pub implementation_plan_md: Option<String>,
    pub overview_txt: Option<String>,
}

/// 讀取 Brain artifacts（~/.gemini/antigravity/brain/{conversation_id}/）
pub fn read_brain_artifacts(brain_dir: &str) -> Option<BrainDump> {
    let dir = Path::new(brain_dir);
    if !dir.exists() { return None; }

    let task = read_optional_file(&dir.join("task.md"));
    let walkthrough = read_optional_file(&dir.join("walkthrough.md"));
    let plan = read_optional_file(&dir.join("implementation_plan.md"));
    let overview = read_optional_file(
        &dir.join(".system_generated").join("logs").join("overview.txt")
    );

    if task.is_none() && walkthrough.is_none() && plan.is_none() && overview.is_none() {
        return None;
    }

    Some(BrainDump {
        task_md: task,
        walkthrough_md: walkthrough,
        implementation_plan_md: plan,
        overview_txt: overview,
    })
}

/// 將 BrainDump 轉為 Markdown
pub fn brain_dump_to_markdown(dump: &BrainDump, conversation_id: &str) -> String {
    let mut md = format!("# Brain Artifacts Dump: {}\n\n> Source: Brain FS\n\n", conversation_id);

    if let Some(ref content) = dump.task_md {
        md.push_str(&format!("## task.md\n\n{}\n\n---\n\n", content));
    }
    if let Some(ref content) = dump.walkthrough_md {
        md.push_str(&format!("## walkthrough.md\n\n{}\n\n---\n\n", content));
    }
    if let Some(ref content) = dump.implementation_plan_md {
        md.push_str(&format!("## implementation_plan.md\n\n{}\n\n---\n\n", content));
    }
    if let Some(ref content) = dump.overview_txt {
        md.push_str(&format!("## overview.txt\n\n{}\n\n---\n\n", content));
    }

    md
}

fn read_optional_file(path: &Path) -> Option<String> {
    std::fs::read_to_string(path).ok()
}
