use aes_gcm::{Aes256Gcm, Key, Nonce};
use aes_gcm::aead::Aead;
use aes_gcm::KeyInit;
use std::path::{Path, PathBuf};

/// Antigravity PB 加密密鑰（Phase 16/Phase 21 發現）
/// AES-256-GCM, key = "safeCodeiumworldKeYsecretBalloon" (32 bytes)
pub const PB_KEY: &[u8; 32] = b"safeCodeiumworldKeYsecretBalloon";

/// 解密單一 PB 資料區塊
/// 格式: [12 bytes nonce] + [ciphertext + 16 bytes auth tag]
pub fn decrypt_pb(data: &[u8]) -> Result<Vec<u8>, String> {
    if data.len() < 13 {
        return Err(format!("資料過小: {} bytes (至少需 13)", data.len()));
    }

    let key = Key::<Aes256Gcm>::from_slice(PB_KEY);
    let cipher = Aes256Gcm::new(key);
    let nonce = Nonce::from_slice(&data[..12]);

    cipher.decrypt(nonce, &data[12..])
        .map_err(|e| format!("AES-256-GCM 解密失敗: {:?}", e))
}

/// 解密 PB 檔案並寫入輸出目錄
pub fn decrypt_pb_file(pb_path: &Path, out_dir: &Path) -> Result<(PathBuf, usize, usize), String> {
    let data = std::fs::read(pb_path)
        .map_err(|e| format!("讀取失敗 {}: {}", pb_path.display(), e))?;
    
    let plaintext = decrypt_pb(&data)?;
    
    let stem = pb_path.file_stem().unwrap().to_string_lossy();
    let out_path = out_dir.join(format!("{}.proto.bin", stem));
    std::fs::write(&out_path, &plaintext)
        .map_err(|e| format!("寫入失敗 {}: {}", out_path.display(), e))?;
    
    Ok((out_path, data.len(), plaintext.len()))
}

/// 批量解密 PB 檔案
pub fn decrypt_pb_batch(pattern: &str, out_dir: &Path) -> (usize, usize) {
    let files: Vec<PathBuf> = if pattern.contains('*') || pattern.contains('?') {
        glob::glob(pattern).unwrap().filter_map(|r| r.ok()).collect()
    } else {
        let p = PathBuf::from(pattern);
        if p.is_dir() {
            glob::glob(&format!("{}/*.pb", pattern)).unwrap().filter_map(|r| r.ok()).collect()
        } else {
            vec![p]
        }
    };

    std::fs::create_dir_all(out_dir).ok();
    let mut ok = 0;
    let mut fail = 0;

    for pb_path in &files {
        match decrypt_pb_file(pb_path, out_dir) {
            Ok((out_path, orig_size, dec_size)) => {
                eprintln!("✅ {} → {} ({} → {} bytes)",
                    pb_path.file_name().unwrap().to_string_lossy(),
                    out_path.display(), orig_size, dec_size);
                ok += 1;
            }
            Err(e) => {
                eprintln!("❌ {}: {}", pb_path.file_name().unwrap().to_string_lossy(), e);
                fail += 1;
            }
        }
    }

    (ok, fail)
}
